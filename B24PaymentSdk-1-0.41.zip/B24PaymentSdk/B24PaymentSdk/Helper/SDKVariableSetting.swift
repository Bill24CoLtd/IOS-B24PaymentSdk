//
//  SDKVariable.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 31/10/23.
//

import Foundation
public class SDKVariableSetting{
    public static var xRefererKey: String = "BcfBFIjKmbmKJxYDmwkFz1947Mg6IDzzCBM3UCAsTMtdXc77DEFAiV1fyGUy"
    public static var currentLanguage: String = ""
    public static var isDarkMode: Bool = false
    public static var isProduction: Bool = false

   // public static let merchantApiBaseUrlStaging = "https://staging.oone.bz:50445"

    public static let merchantApiBaseUrlStaging = "https://merchantapi-staging.bill24.io"
    public static let merchantApiBaseUrlDemo = "https://merchantapi-demo.bill24.io"
    public static let merchantApiBaseUrlPilot = "https://portal-staging.bill24.io:40140"
    public static let merchantApiBaseUrlProduction = "https://merchantapi.bill24.io"

    public static let apiToken = "529404f1-e439-45ba-b3f2-cdd7dc3cc336"


    public static let socketBaseUrlStaging = "https://staging.oone.bz:40018"
    // public static let socketBaseUrlPilot = "https://portal-staging.bill24.io:40154"
    public static let socketBaseUrlDemo = "https://socket-demo.bill24.io"
    public static let socketBaseUrlProduction = "https://socketserver.bill24.io"

    //public static let versionStaging = "1.0.0.0"
    //public static let versionDemo = "1.0.0.0"
    //public static let versionProduction = "1.0.0.0"
    public static let version = "1.0.38.1"

    public static let bill24WebsiteUrl = "https://bill24.com.kh/en/"

    public static let walletSecretKey = "viGRVikFx9am8dvDELcKxKuQ157aawRqDk94a7EfhXA40TDJPrOICaQj99tAu6UG"
    public static var testingEnv="DEMO"
}

