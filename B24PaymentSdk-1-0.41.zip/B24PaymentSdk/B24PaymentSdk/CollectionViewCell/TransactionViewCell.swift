//
//  TransactionViewCell.swift
//  B24PaymentSdk
//
//  Created by visal ny on 24/12/24.
//

import UIKit

class TransactionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var container: UIView!
    
    @IBOutlet weak var line: UIView!
    
    @IBOutlet weak var bgLogo: UIView!
    
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var tranDateLabel: UILabel!
    
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
}
