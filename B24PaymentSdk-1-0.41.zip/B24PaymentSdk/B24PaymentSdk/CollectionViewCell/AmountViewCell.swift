//
//  AmountViewCell.swift
//  B24PaymentSdk
//
//  Created by visal ny on 25/12/24.
//

import UIKit

class AmountViewCell: UICollectionViewCell {
    
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var amountLabel: UILabel!
}
