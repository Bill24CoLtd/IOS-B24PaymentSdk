//
//  PaymentMethodViewCell.swift
//  B24PaymentSdk
//
//  Created by visal ny on 27/12/24.
//

import UIKit

class PaymentMethodViewCell: UICollectionViewCell {
    
    @IBOutlet weak var bgCardView: UIView!
    @IBOutlet weak var bgLogo: UIView!
    
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    
    @IBOutlet weak var defaultIcon: UIImageView!
    
    @IBOutlet weak var inactiveLabel: UILabel!
    @IBOutlet weak var bgInactive: UIView!
    @IBOutlet weak var overlayContainer: UIView!
    
    @IBOutlet weak var overlayLabel: UILabel!
    @IBOutlet weak var overlayIcon: UIImageView!
}
