//
//  AvailabelPMCollectionViewCell.swift
//  B24PaymentSdk
//
//  Created by visal ny on 19/12/24.
//

import UIKit

class AvailabelPMCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var paymentMethodTypeCardView: UIView!
    @IBOutlet weak var backgroundLogo: UIView!
    @IBOutlet weak var paymentMethodTypeIcon: UIImageView!
    @IBOutlet weak var paymentMethodTypeTitle: UILabel!
        
    
}



