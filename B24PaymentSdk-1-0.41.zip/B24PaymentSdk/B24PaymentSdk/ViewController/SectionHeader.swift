//
//  SectionHeader.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 16/10/23.
//

import Foundation
import UIKit

public class SectionHeader: UICollectionReusableView {
    @IBOutlet weak var titleLabel: UILabel!
    public override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
