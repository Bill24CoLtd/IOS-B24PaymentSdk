//
//  BottomSheetViewController.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 12/10/23.
//

import Foundation
import UIKit
import SocketIO
import Alamofire

public class BottomSheetViewController: UIViewController{
    @IBOutlet weak var topBarView: UIView!
    @IBOutlet weak var bottomSheetContainerView: UIView!
    private var bottomSheetHeightConstraint: NSLayoutConstraint?
    private var manager: SocketManager!
    private var socket: SocketIOClient!
    
    public var completed: (() -> Void)? = nil
    var activityViewController: UIActivityViewController?
    public var shareActivityItems: [Any] = []
    
    var viewType: BottomSheetViewType = .full
    var transactionId: String = ""
    private var alreadyCalledVerify: Bool = false
    
    public static var bottomSheetHeight: CGFloat = 0
    
    private var controller: BottomSheetViewController!
   
    public func appearanceSetup(){
        if !Themes.Property.indicatorColor.isEmpty {
            topBarView.backgroundColor = UIColor(hex: Themes.Property.indicatorColor)
        }
        
        if !Themes.Property.secondaryBackgroundColor.isEmpty{
            view.backgroundColor = UIColor(hex: Themes.Property.secondaryBackgroundColor)
        }
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if isBeingDismissed && completed != nil{
            completed!()
        }
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        print("**** BottomSheet ****")
        appearanceSetup()
        registerBottomSheetStyleAndConstraint()
        initSocketServer(roomName: "\(APIManager.serviceName())-\(transactionId)")
        subscribeBroadcastEvent()
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        panGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(panGesture)
        
        // Register to receive the notification when back from other app
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(applicationDidBecomeActive),
                                               name: UIApplication.didBecomeActiveNotification,
                                               object: nil)
    }
    
    deinit {
        // Unregister the observer when the object is deallocated
        NotificationCenter.default.removeObserver(self,
                                                  name: UIApplication.didBecomeActiveNotification,
                                                  object: nil)
    }
    
    // Selector method that will be called when the notification is received
    @objc func applicationDidBecomeActive() {
        // Perform tasks when the application becomes active
        self.verifyTransaction(transactionId: transactionId, alreadyCalledVerify: self.alreadyCalledVerify)
    }
    
    @objc func handlePanGesture(_ recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: view)
        let velocity = recognizer.velocity(in: view)

        switch recognizer.state {
        case .changed:
            // Move the bottom sheet with the gesture
            view.transform = CGAffineTransform(translationX: 0, y: translation.y)
            // Call updateCountdown here
        case .ended:
            // Dismiss the bottom sheet if the swipe velocity is downward
            if velocity.y > 0 {
                dismissBottomSheet()
            } else {
                // If the swipe is upward, reset the position of the bottom sheet
                UIView.animate(withDuration: 0.3) {
                    self.view.transform = .identity
                }
            }
        default:
            break
        }
    }
    
    func dismissBottomSheet() {
        UIView.animate(withDuration: 0.3, animations: {
            // Move the bottom sheet off the screen for dismissal effect
            self.view.transform = CGAffineTransform(translationX: 0, y: self.view.frame.height)
        }) { _ in
            // Remove the bottom sheet from the superview or perform any desired action
            self.dismiss(animated: true)
            
        }
    }
    
    public func registerBottomSheetStyleAndConstraint(){
        topBarView.layer.cornerRadius = 3
        // Set up height constraint for bottomSheetContainerView
        bottomSheetHeightConstraint = bottomSheetContainerView.heightAnchor.constraint(equalToConstant: UIScreen.main.bounds.height / 2)
        bottomSheetHeightConstraint?.isActive = true
        
        // Set corner radius
        bottomSheetContainerView.layer.cornerRadius = 12
        
        // Call updateViewConstraints to make sure it's applied immediately
        view.setNeedsUpdateConstraints()
    }
    
    public override func updateViewConstraints() {
        if  bottomSheetHeightConstraint != nil {
            switch viewType {
            case .full:
                updateViewConstraintsForFull()
            case .sixtyPercent:
                updateViewConstraintsForSixtyPercent()
            case .thirtyPercent:
                updateViewConstraintsForThirtyPercent()
            }
        }
        super.updateViewConstraints()
    }
    
    private func updateViewConstraintsForFull() {
        self.view.layer.cornerRadius = 12
        self.view.frame.size.height = UIScreen.main.bounds.height
        self.view.frame.origin.y = 0
        BottomSheetViewController.bottomSheetHeight = self.view.frame.size.height + self.view.frame.origin.y - 80
    }
    
    private func updateViewConstraintsForSixtyPercent() {
        // Implement layout for 65% height here
        self.view.layer.cornerRadius = 12
        self.view.frame.size.height = UIScreen.main.bounds.height * 0.65
        self.view.frame.origin.y = UIScreen.main.bounds.height * 0.175
        BottomSheetViewController.bottomSheetHeight = self.view.frame.size.height + self.view.frame.origin.y - 80
    }
    
    private func updateViewConstraintsForThirtyPercent() {
        // Implement layout for 30% height here
        self.view.layer.cornerRadius = 12
        self.view.frame.size.height = UIScreen.main.bounds.height / 2
        self.view.frame.origin.y = UIScreen.main.bounds.height / 2
        BottomSheetViewController.bottomSheetHeight = self.view.frame.size.height - 80
    }
    
    private func initSocketServer(roomName: String){
        let config: SocketIOClientConfiguration = [.log(true), .compress, .forceWebsockets(true)]
        manager = SocketManager(socketURL: APIManager.socketServerUrl(), config: config)
        socket = manager.defaultSocket
        
        socket.on(clientEvent: .connect) { [self] data, ack in
            print("**** Socket Connected *****")
            socket.emit("joinRoom", "\(APIManager.serviceName())-\(transactionId)");
        }
        
        socket.on(clientEvent: .disconnect) { data, ack in
            print("*** Socket disconnected ***")
            
        }
        socket.connect()
    }
    
    private func verifyTransaction(transactionId: String, alreadyCalledVerify: Bool){
        if(alreadyCalledVerify == false){
            AF.request(CheckoutRouter.checkoutDetail(transactionId: transactionId)).validate().responseData{
                (response) in
                switch response.result{
                case .success(let data):
                    let transaction = try? JSONDecoder().decode(Transaction.self, from: data)
                    if(transaction?.code == "SUCCESS"){
                        if(transaction?.data?.transInfo.status == "success"){
                            let displayDefaultSuccessPage = transaction?.data?.checkoutPageConfig.displaySuccessPage
                            let merchantDeeplink = transaction?.data?.transInfo.redirectURL
                             
                            if(displayDefaultSuccessPage == true){
                                
                                //check to open success in wallet
                                    let storyboard = UIStoryboard(name: "SuccessScreenViewController", bundle: B24PaymentSdkHelper.frameworkBundle())
                                    let vc = storyboard.instantiateViewController(withIdentifier: "SuccessScreenViewController") as! SuccessScreenViewController
                                    vc.transactionSuccess = transaction
                                    vc.presentingVC = self
                                    vc.modalPresentationStyle = .fullScreen
                                    self.present(vc, animated: true)
                               
                                
                                
                                
                                
                               
                                
                            }else{
                                self.dismiss(animated: true){
                                    B24PaymentSdkHelper.openDeeplink(deepLinkUrl: merchantDeeplink ?? "", view: self.view)
                                }
                            }
                        }
                        self.alreadyCalledVerify = true
                    }else{
//                        print("Error\(String(describing: transaction?.messageKh))")
//                        B24PaymentSdkHelper.errorSnackbar(
//                            view: self.view,
//                            message: (transaction?.messageKh ?? transaction?.message) ??  B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
//                            forBottomSheet: false
//                        )
                        //let lan = SDKVariableSetting.currentLanguage?.lowercased() ?? "km"
                        let message = SDKVariableSetting.currentLanguage.lowercased() == "en" ? transaction?.message : transaction?.messageKh

                        B24PaymentSdkHelper.errorSnackbar(
                            view: self.view,
                            message: message ?? B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                            forBottomSheet: false
                        )
                    }
                case .failure(let error):
                    print(error)
                    B24PaymentSdkHelper.errorSnackbar(
                        view: self.view,
                        message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                        forBottomSheet: false
                    )
                }
            }
        }
    }
    
    private func subscribeBroadcastEvent(){
        socket.on("broadcast") { data, ack in
            if let dictionary = data[0] as? [String: Any],
               let transactionId = dictionary["transactionId"] as? String {
                self.verifyTransaction(transactionId: transactionId, alreadyCalledVerify: self.alreadyCalledVerify)
            }
        }
    }
}







