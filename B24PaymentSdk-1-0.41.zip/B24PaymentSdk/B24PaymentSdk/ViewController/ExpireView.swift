//
//  ExpireView.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 23/10/23.
//

import Foundation
import UIKit

public class ExpireView : UIView{
    
    @IBOutlet weak var expireTitlteLabel: UILabel!
    @IBOutlet weak var retryButton: UIButton!
    
    var controller: UIViewController!
    var transactionId: String = ""
    var transactionData: Transaction?

    @IBOutlet weak var dotLineView: DottedLineView!
    @IBOutlet weak var expireContent: UILabel!
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initSubviews()
    }
    
    init(frame: CGRect,transactionId: String, controller: UIViewController, transactionData: Transaction) {
        self.transactionData = transactionData
        self.transactionId = transactionId
        self.controller = controller
        super.init(frame: frame)
        initSubviews()
    }
    
    private func initSubviews() {
        registerView()
        setUpStyle()
        setUpFont()
        setUpThemes()
        setUpTranslate()
    }
    
    private func setUpThemes(){
        expireTitlteLabel.textColor = UIColor(hex: Themes.Property.primaryTextColor)
        expireContent.textColor = UIColor(hex: Themes.Property.primaryTextColor)
        dotLineView.tintColor = UIColor(hex: Themes.Property.indicatorColor)
        retryButton.backgroundColor = UIColor(hex: Themes.Property.buttonBackgroundColor)
        retryButton.tintColor = UIColor(hex: Themes.Property.buttonTextColor)
        retryButton.titleLabel?.textColor = UIColor(hex: Themes.Property.buttonTextColor)
    }
    
    private func setUpFont(){
        expireContent.font = FontManager.shared.regularFont(forLanguage: SDKVariableSetting.currentLanguage, size: 16.0)
        expireTitlteLabel.font = FontManager.shared.boldFont(forLanguage: SDKVariableSetting.currentLanguage, size: 18.0)
        retryButton.titleLabel?.font = FontManager.shared.regularFont(forLanguage: SDKVariableSetting.currentLanguage, size: 14.0)
    }
    
    private func setUpTranslate(){
        retryButton.setTitle(B24PaymentSdkHelper.localized(ExpireLocalizedKeys.button.rawValue), for: .normal)
        expireTitlteLabel.text = B24PaymentSdkHelper.localized(ExpireLocalizedKeys.title.rawValue)
        expireContent.text = B24PaymentSdkHelper.localized(ExpireLocalizedKeys.description.rawValue)
    }
    
    @IBAction func onClickRetryButton(_ sender: Any) {
        B24PaymentSdkHelper.navigationToNextBottomSheet(from: controller) { [self] in
            let b24PaymentSdkHelper = B24PaymentSdkHelper()
            let khqrView = KHQRView(
                frame: controller.view.frame,
                transactionId: transactionId,
                controller: controller,
                transactionData: transactionData!,
                bottomSheetController: b24PaymentSdkHelper.vc
            )
            b24PaymentSdkHelper.presentBottomSheet(
                from: controller,
                view: khqrView,
                viewType: .sixtyPercent,
                transactionId: transactionId,
                completed: {
                    khqrView.completed()
                }
            )
        }
    }
    
    private func registerView(){
        let nib = UINib(
            nibName: "ExpireView",
            bundle: B24PaymentSdkHelper.frameworkBundle()
        )
        
        guard let view = nib.instantiate(withOwner: self, options: nil).first as?
                UIView else {fatalError("Unable to convert nib")}
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        addSubview(view)
        print("*** Load Expire View ***")
        view.backgroundColor = UIColor(hex: Themes.Property.secondaryBackgroundColor)
    }
    
    private func setUpStyle(){
        retryButton.layer.cornerRadius = 10
    }
}
