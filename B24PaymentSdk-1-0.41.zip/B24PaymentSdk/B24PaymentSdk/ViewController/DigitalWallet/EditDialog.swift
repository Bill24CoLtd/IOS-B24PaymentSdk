//
//  EditDialog.swift
//  B24PaymentSdk
//
//  Created by visal ny on 25/12/24.
//

import UIKit

class EditDialog: UIViewController {
    
    @IBOutlet weak var dialogContainer: UIView!
    
    @IBOutlet weak var inputField: UITextField!
    @IBOutlet weak var buttonCancel: UIButton!
    @IBOutlet weak var buttonOk: UIButton!
    
    var okActionHandler: ((_ inputText: String) -> Void)?
    var cancelActionHandler: (() -> Void)?
    private var initialText: String = ""

    
    var language:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)

        
        getSharePref()
        
        setUpUI()

        inputField.text = initialText


    }
    
    
    func getSharePref(){
        if let languageCode = SharedPreferenceManager.getString(forKey: SharePrefKey.lanuageCode.rawValue){
            language = languageCode
        }else{
            language = "km"
        }
    }
    
    
    func setUpUI(){
        dialogContainer.backgroundColor = DefaultAppearance.shared.cardColor
        dialogContainer.layer.cornerRadius = 8
        inputField.layer.cornerRadius = 8.0
        inputField.backgroundColor = DefaultAppearance.shared.screenBgColor
        inputField.textColor = DefaultAppearance.shared.primaryLabelColor
        
        let placeholderText = "Enter Title"
        let placeholderColor = DefaultAppearance.shared.primaryLabelColor

        inputField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [NSAttributedString.Key.foregroundColor: placeholderColor]
        )
        
        self.addPadding(to: inputField)
        
        
        buttonOk.tintColor = DefaultAppearance.shared.primaryColor
        buttonOk.setTitleColor(DefaultAppearance.shared.onPrimaryColor, for: .normal)
        buttonOk.titleLabel?.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
        
        buttonCancel.setTitleColor(DefaultAppearance.shared.primaryLabelColor, for: .normal)
        buttonCancel.titleLabel?.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
    }
    
    func configure(
            okButtonTitle: String,
            cancelButtonTitle: String,
            okHandler: @escaping (_ inputText: String) -> Void,
            cancelHandler: @escaping () -> Void
    ) {
        
        DispatchQueue.main.async {
            if let okButton = self.buttonOk {
                okButton.setTitle(okButtonTitle, for: .normal)
            }
            if let cancelButton = self.buttonCancel {
                cancelButton.setTitle(cancelButtonTitle, for: .normal)
            }
       
            
            self.okActionHandler = okHandler
            self.cancelActionHandler = cancelHandler
        }
    }
    
    
    @IBAction func cancelAction(_ sender: Any) {
        dismiss(animated: true) {
          self.cancelActionHandler?()
        }
    }
    @IBAction func okAction(_ sender: Any) {
        guard let inputText = inputField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !inputText.isEmpty else {
            inputField.layer.borderWidth = 1
            inputField.layer.masksToBounds = true
            inputField.layer.cornerRadius = 8.0
            inputField.layer.borderColor = UIColor.red.cgColor
           
            return
        }
        dismiss(animated: true) {
            self.okActionHandler?(inputText)
        }
    }
    

    func setDefaultText(_ text: String) {
        self.initialText = text
    }

    func showEditDialog(from presentingViewController: UIViewController,
                       defaultText: String = "",
                       okHandler: @escaping (_ inputText: String) -> Void,
                       cancelHandler: @escaping () -> Void) {
        let storyboard = UIStoryboard(name: "InstantPaymentMethodView", bundle: B24PaymentSdkHelper.frameworkBundle())
        guard let alertView = storyboard.instantiateViewController(withIdentifier: "EditDialogView") as? EditDialog else {
            return
        }

        alertView.modalPresentationStyle = .overFullScreen
        alertView.modalTransitionStyle = .crossDissolve

        alertView.setDefaultText(defaultText)  // Set the default text

        alertView.configure(
            okButtonTitle: B24PaymentSdkHelper.localized(DialogLocalizedKeys.ok.rawValue),
            cancelButtonTitle: B24PaymentSdkHelper.localized(DialogLocalizedKeys.cancel.rawValue),
            okHandler: okHandler,
            cancelHandler: cancelHandler
        )

        presentingViewController.present(alertView, animated: true)
    }

   
    func addPadding(to textField: UITextField) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: textField.frame.height))
        textField.leftView = paddingView
        textField.leftViewMode = .always
    }
    
}
