//
//  TransactionDetailView.swift
//  B24PaymentSdk
//
//  Created by visal ny on 24/12/24.
//

import UIKit
import Alamofire

class TransactionDetailView: UIViewController {

    @IBOutlet weak var bgContainer: UIView!
    
    @IBOutlet weak var imageDownload: UIView!
    @IBOutlet weak var indicator: UIView!
    
    @IBOutlet weak var bgLogo: UIView!
    @IBOutlet weak var line: UIView!
    @IBOutlet weak var dashLine: UIView!
    
    @IBOutlet weak var shareContainer: UIView!
    @IBOutlet weak var downloadContainer: UIView!
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var amountLable: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var tranIdLabel: UILabel!
    @IBOutlet weak var invoiceIdText: UILabel!
    @IBOutlet weak var paidPayText: UILabel!
    @IBOutlet weak var originalAmountText: UILabel!
    @IBOutlet weak var feeText: UILabel!
    @IBOutlet weak var referenceText: UILabel!
    @IBOutlet weak var tranDateText: UILabel!
    @IBOutlet weak var tranIdValue: UILabel!
    @IBOutlet weak var invoiceIdValue: UILabel!
    @IBOutlet weak var paidPayValue: UILabel!
    @IBOutlet weak var feeValue: UILabel!
    @IBOutlet weak var originalAmountValue: UILabel!
    @IBOutlet weak var referenceValue: UILabel!
    @IBOutlet weak var tranDateValue: UILabel!
    
    @IBOutlet weak var downshareContainer: UIView!
    
    @IBOutlet weak var bgDownloadLogo: UIView!
    
    @IBOutlet weak var downloadLogo: UIImageView!
    
    @IBOutlet weak var downloadText: UILabel!
    @IBOutlet weak var shareLogo: UIImageView!
    
    @IBOutlet weak var shareText: UILabel!
    @IBOutlet weak var bgShareLogo: UIView!
    @IBOutlet weak var emptyLabel: UILabel!
    @IBOutlet weak var emptyImage: UIImageView!
    
    @IBOutlet weak var progressContainerMain: UIView!
    
    @IBOutlet weak var progressMain: UIActivityIndicatorView!
    private let activityIndicator = UIActivityIndicatorView(style: .medium)
    var tranID: String = ""
    var tranDetail = DataWalletTransactionDetail()
    var language: String?
    let emptyIconName = "person.crop.circle"


    private var isLoading: Bool = false {
            didSet {
                if isLoading {
                    LoadingIndicatorManager.shared.showLoading(in: view)
                } else {
                    LoadingIndicatorManager.shared.hideLoading()
                }
            }
        }

    override func viewDidLoad() {
          super.viewDidLoad()
          setupUI()
          fetchTransactionDetails()
      }
    
    private func startLoading(){
        emptyImage.isHidden = true
        emptyLabel.isHidden = true
        progressContainerMain.backgroundColor = DefaultAppearance.shared.cardColor
        progressMain.tintColor = DefaultAppearance.shared.primaryColor
        progressMain.startAnimating()
    }
    
    private func stopLoading(){
        progressContainerMain.isHidden = true
    }
    

    private func setupUI() {
        view.backgroundColor = UIColor.clear
        downloadContainer.backgroundColor = DefaultAppearance.shared.cardColor
        shareContainer.backgroundColor = DefaultAppearance.shared.cardColor
        imageDownload.backgroundColor = DefaultAppearance.shared.cardColor

        getSharePref()
        
        B24PaymentSdkHelper.getCurrentLanguage(language: language)

        indicatorAppearance()
        setUpAppearance()
        setupDownloadShare()
        setupGestureRecognizers()
    }

    private func setupGestureRecognizers() {
        bgShareLogo.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(shareImage)))
        bgDownloadLogo.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(downloadImage)))
        bgShareLogo.isUserInteractionEnabled = true
        bgDownloadLogo.isUserInteractionEnabled = true
    }

    private func fetchTransactionDetails() {
        
    
        
      //  print("===============>\(tranID)")
        
//        AF.request(WalletRouter.transactionDetail(id: tranID))
//            .validate().responseDecodable(){
//                [self](response) in
//                switch response.result{
//                case .success(let data):
//                    do{
//                        let decodedData = try JSONDecoder().decode(ApiResponse<DataWalletTransactionDetail>.self, from: data)
//                        
//                       
//                        if(decodedData.code == "SUCCESS"){
//                            stopLoading()
//                            self.handleSuccessResponse(decodedData.data)
//                        }else{
//                            progressMain.stopAnimating()
//                            progressMain.isHidden = true
//                            
//                            emptyImage.image = UIImage(systemName: emptyIconName)
//                            emptyImage.tintColor = DefaultAppearance.shared.warningColor
//                            emptyLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
//                            emptyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
//                            emptyLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
//                            
//                            
//                            let message = language == "en" ? decodedData.message : decodedData.messageKh
//                            
//                            B24PaymentSdkHelper.errorSnackbar(view: view,
//                                                              message: message )
//                        }
//                    }catch{
//                        print("Decode Error: \(error)")
//                    }
//                    
//                case .failure(let error):
//                    progressMain.stopAnimating()
//                    progressMain.isHidden = true
//                    
//                    emptyImage.image = UIImage(systemName: emptyIconName)
//                    emptyImage.tintColor = DefaultAppearance.shared.warningColor
//                    emptyLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
//                    emptyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
//                    emptyLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
//                    
//                    B24PaymentSdkHelper.errorSnackbar(
//                                    view: view,
//                                    message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
//                                                        forBottomSheet: false
//                                                )
//                }
//            }
        
        
       // isLoading = true
        
        startLoading()

        let url = APIManager.merchantApiUrl().appendingPathComponent("instantpaymentsdk/payment_method/transaction_detail")
        let parameters: [String: Any] = ["tran_id": tranID]

        AF.request(
            url,
            method: .post,
            parameters: parameters,
            encoding: JSONEncoding.default,
            headers: APIManager.initHeader()
        )
        .validate()
        .responseDecodable(of: TransactionDetailResponseModel.self) { [weak self] response in
            guard let self = self else { return }
           // self.isLoading = false

            switch response.result {
            case .success(let responseModel):
                if responseModel.code == "SUCCESS" {
                    stopLoading()
                    self.handleSuccessResponse(responseModel.data)
                } else {
//                    self.showAlert(title: "Error", message: responseModel.message)
                    progressMain.stopAnimating()
                                                progressMain.isHidden = true
                    
                                                emptyImage.image = UIImage(systemName: emptyIconName)
                                                emptyImage.tintColor = DefaultAppearance.shared.warningColor
                                                emptyLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
                                                emptyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
                                                emptyLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
                    let message = language == "en" ? responseModel.message : responseModel.messageKh
                    
                                                B24PaymentSdkHelper.errorSnackbar(view: view,
                                                                                  message: message )
                }
            case .failure(let error):
                
                print("error \(error)")
              //  self.showAlert(title: "Error", message: error.localizedDescription)
                progressMain.stopAnimating()
                progressMain.isHidden = true
                
                                    emptyImage.image = UIImage(systemName: emptyIconName)
                                    emptyImage.tintColor = DefaultAppearance.shared.warningColor
                                    emptyLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
                                    emptyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
                                    emptyLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
                
                                    B24PaymentSdkHelper.errorSnackbar(
                                                    view: view,
                                                    message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                                                                        forBottomSheet: false
                                                                )
            }
        }
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func handleSuccessResponse(_ data: DataWalletTransactionDetail) {
        tranDetail = data
        setUpHeaderAppearance(detail: data)
        setUpContentAppearance(detail: data)
    }

//    private func handleSuccessResponse(_ data: DataWalletTransactionDetail) {
//        self.tranDetail = data
//        setUpHeaderAppearance(detail: data)
//        setUpContentAppearance(detail: data)
//    }

    private func handleError(_ error: AFError) {
        let errorMessage = error.localizedDescription
        showError(message: errorMessage)
    }

    private func showError(message: String) {
        // Implement your error handling UI here
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func setupActivityIndicator() {
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([
            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }


    
    func getSharePref(){
        if let languageCode = SharedPreferenceManager.getString(forKey: SharePrefKey.lanuageCode.rawValue){
            language = languageCode
        }else{
            language = "km"
        }
    }
    
    
    func setUpHeaderAppearance(detail: DataWalletTransactionDetail) {
        if detail.tranType == TransactionType.walletTopup.rawValue {
            bgLogo.backgroundColor = DefaultAppearance.shared.primaryColor.withAlphaComponent(0.4)
            logo.tintColor = DefaultAppearance.shared.primaryColor
            bgLogo.layer.cornerRadius = bgLogo.frame.size.width/2
            bgLogo.clipsToBounds = true
            logo.image = UIImage(systemName: "arrow.up.left")
        } else {
            bgLogo.backgroundColor = DefaultAppearance.shared.dangerColor.withAlphaComponent(0.4)
            bgLogo.layer.cornerRadius = bgLogo.frame.size.width/2
            bgLogo.clipsToBounds = true
            logo.image = UIImage(systemName: "arrow.down.left")
            logo.tintColor = DefaultAppearance.shared.dangerColor
        }

        amountLable.text = detail.originalAmountDisplay + " " + detail.currency
        amountLable.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        amountLable.textColor = DefaultAppearance.shared.secondaryLabelColor

        detailLabel.text = detail.tranType
        detailLabel.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishRegular, ofSize: FixFontSize.contentText)
        detailLabel.textColor = DefaultAppearance.shared.secondaryLabelColor
    }

    func shareAction(){
        bgShareLogo.isUserInteractionEnabled = true
        let shareAction = UITapGestureRecognizer(target: self, action: #selector(shareImage))
        
        bgShareLogo.addGestureRecognizer(shareAction)
    }
    
    
    @objc func shareImage(){
        
        let image = imageDownload.saveAsImage() // Assuming saveAsImage() returns a UIImage
        
        let imageName = "image.png"
        // Get the URL for the documents directory
        if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            // Append the custom image name to the documents directory URL
            let fileURL = documentsDirectory.appendingPathComponent(imageName)
            
            // Save the image to the specified URL
            if let data = image.pngData() {
                do {
                    try data.write(to: fileURL)
                    let items: [Any] = [image, imageName]
                    // Now you can share the image using UIActivityViewController
                    let activityViewController = UIActivityViewController(activityItems: items, applicationActivities: nil)
                    
                    // For iPads, you need to specify a source view and arrow direction for the popover
                    activityViewController.popoverPresentationController?.sourceView = self.view
                    activityViewController.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                    // Present the activity view controller
                    self.present(activityViewController, animated: true, completion: nil)
                } catch {
                    print("Error saving image: \(error)")
                }
            }
        }
      
       
    }
    
    
    func downLoadAction(){
        bgDownloadLogo.isUserInteractionEnabled = true
        let downloadAction = UITapGestureRecognizer(target: self, action: #selector(downloadImage))
        
        bgDownloadLogo.addGestureRecognizer(downloadAction)
    }
    
    @objc func downloadImage(){
     let image =   imageDownload.saveAsImage()
      saveImageToPhotoLibrary(image: image)
        print("downLoad")
    }
    
    private func saveImageToPhotoLibrary(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            print(error)
//            B24PaymentSdkHelper.errorSnackbar(
//                view: self,
//                message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
//                forBottomSheet: true
//            )
        } else {
//            B24PaymentSdkHelper.successSnackbar(
//                view: self,
//                message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.saveKhqr.rawValue),
//                forBottomSheet: true
//            )
        }
    }
    
    
    func setUpContentAppearance(detail: DataWalletTransactionDetail) {
        tranIdLabel.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.tran_id.rawValue)
        tranIdLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        tranIdLabel.textColor = DefaultAppearance.shared.secondaryLabelColor

        tranIdValue.text = detail.tranNo
        tranIdValue.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        tranIdValue.textColor = DefaultAppearance.shared.secondaryLabelColor

//        invoiceIdText.isHidden = true
//        invoiceIdText.constraints.forEach { constraint in
//                if constraint.firstAttribute == .height {
//                    constraint.constant = 0
//                }
//            }
//        invoiceIdValue.isHidden = true
//        invoiceIdValue.constraints.forEach { constraint in
//                if constraint.firstAttribute == .height {
//                    constraint.constant = 0
//                }
//            }
//        
//        invoiceIdText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.invoice_id.rawValue)
//        invoiceIdText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
//        invoiceIdText.textColor = DefaultAppearance.shared.secondaryLabelColor
//
//        invoiceIdValue.text = detail.refNo
//        invoiceIdValue.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
//        invoiceIdValue.textColor = DefaultAppearance.shared.secondaryLabelColor

        if detail.tranType == TransactionType.walletTopup.rawValue {
            paidPayText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.payment_from.rawValue)
            paidPayValue.text = detail.paymentFrom
        } else {
            paidPayText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.paid_to.rawValue)
            paidPayValue.text = detail.paidTo
        }

        paidPayText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        paidPayText.textColor = DefaultAppearance.shared.secondaryLabelColor

        paidPayValue.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        paidPayValue.textColor = DefaultAppearance.shared.secondaryLabelColor

        originalAmountText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.origial_amount.rawValue)
        originalAmountText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        originalAmountText.textColor = DefaultAppearance.shared.secondaryLabelColor

        originalAmountValue.text = detail.originalAmountDisplay
        originalAmountValue.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        originalAmountValue.textColor = DefaultAppearance.shared.secondaryLabelColor

        feeText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.fee_amount.rawValue)
        feeText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        feeText.textColor = DefaultAppearance.shared.secondaryLabelColor

        feeValue.text = detail.feeDisplay
        feeValue.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        feeValue.textColor = DefaultAppearance.shared.secondaryLabelColor

        referenceText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.reference.rawValue)
        referenceText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        referenceText.textColor = DefaultAppearance.shared.secondaryLabelColor

        referenceValue.text = detail.refNo
        referenceValue.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        referenceValue.textColor = DefaultAppearance.shared.secondaryLabelColor

        tranDateText.text = B24PaymentSdkHelper.localized(TransactionDetailLocalizedKeys.tran_date.rawValue)
        tranDateText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        tranDateText.textColor = DefaultAppearance.shared.secondaryLabelColor

        tranDateValue.text = detail.tranDate
        tranDateValue.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.contentText)
        tranDateValue.textColor = DefaultAppearance.shared.secondaryLabelColor
    }

    func indicatorAppearance(){
        indicator.backgroundColor = DefaultAppearance.shared.screenBgColor
        indicator.layer.cornerRadius = 4
        line.backgroundColor = DefaultAppearance.shared.screenBgColor.withAlphaComponent(0.5)
        
        dashLine.backgroundColor = DefaultAppearance.shared.screenBgColor.withAlphaComponent(0.5)
            let shapeLayer = CAShapeLayer()
            

            let path = UIBezierPath()
            path.move(to: CGPoint(x: 0, y: dashLine.bounds.height / 2))
            path.addLine(to: CGPoint(x: dashLine.bounds.width, y: dashLine.bounds.height / 2))
            
            // Set the shape layer path
            shapeLayer.path = path.cgPath
            
            // Set stroke color and width
            shapeLayer.strokeColor = DefaultAppearance.shared.screenBgColor.withAlphaComponent(0.5).cgColor
            shapeLayer.lineWidth = 1
            
            // Set dash pattern (e.g., 4 points on, 2 points off)
            shapeLayer.lineDashPattern = [7, 4]
            
            // Add the shape layer to the view
            dashLine.layer.addSublayer(shapeLayer)

        
    }
    
    func setUpAppearance(){
        bgContainer.backgroundColor = DefaultAppearance.shared.cardColor
        bgContainer.layer.cornerRadius = 8
    }
    
    
    func setupDownloadShare(){
        downshareContainer.backgroundColor = DefaultAppearance.shared.cardColor
        downloadText.text = B24PaymentSdkHelper.localized(LocalizedKeys.download.rawValue)
        downloadText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.tranTypeText)
        downloadText.textColor = DefaultAppearance.shared.secondaryLabelColor
        
        shareText.text = B24PaymentSdkHelper.localized(LocalizedKeys.share.rawValue)
        shareText.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.tranTypeText)
        shareText.textColor = DefaultAppearance.shared.secondaryLabelColor
        
        //logo
        
        bgDownloadLogo.backgroundColor = DefaultAppearance.shared.primaryColor.withAlphaComponent(0.4)
        bgDownloadLogo.layer.cornerRadius = 6
        downloadLogo.tintColor = DefaultAppearance.shared.primaryColor
        
        bgShareLogo.backgroundColor = DefaultAppearance.shared.primaryColor.withAlphaComponent(0.4)
        bgShareLogo.layer.cornerRadius = 6
        shareLogo.tintColor = DefaultAppearance.shared.primaryColor
        
    }
        
    
}


class LoadingIndicatorManager {
    static let shared = LoadingIndicatorManager()
    private var containerView: UIView?
    private let activityIndicator = UIActivityIndicatorView(style: .large)

    private init() {}

    func showLoading(in view: UIView) {
        // Remove any existing loading indicator
        hideLoading()

        // Create semi-transparent container
        let container = UIView()
        container.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        container.translatesAutoresizingMaskIntoConstraints = false

        // Configure activity indicator
        activityIndicator.color = .white
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false

        // Add views to hierarchy
        view.addSubview(container)
        container.addSubview(activityIndicator)

        // Setup constraints
        NSLayoutConstraint.activate([
            container.topAnchor.constraint(equalTo: view.topAnchor),
            container.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            container.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            container.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            activityIndicator.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: container.centerYAnchor)
        ])

        containerView = container
        activityIndicator.startAnimating()
    }

    func hideLoading() {
        activityIndicator.stopAnimating()
        containerView?.removeFromSuperview()
        containerView = nil
    }
}
