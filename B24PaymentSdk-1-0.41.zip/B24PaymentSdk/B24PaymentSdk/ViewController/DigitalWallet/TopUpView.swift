//
//  TopUpView.swift
//  B24PaymentSdk
//
//  Created by visal ny on 25/12/24.
//

import UIKit
import Alamofire

class TopUpView: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    

    @IBOutlet weak var buttonSpaceBottom: NSLayoutConstraint!
    
    @IBOutlet weak var amountCollectionView: UICollectionView!
    
    @IBOutlet weak var contenContainer: UIView!
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var walletNo: UILabel!
    @IBOutlet weak var line: UIView!
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var currencyLabel: UILabel!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var chooseAmountLabel: UILabel!
    @IBOutlet weak var lineChooseAmount: UIView!
    @IBOutlet weak var inputAmount: UITextField!
    @IBOutlet weak var buttonOk: UIButton!
    
    var amountList:[String] = ["10","20","40","50","100","200"]

    let usdAmountList: [String] = ["10", "20", "40", "50", "100", "200"]
    let khrAmountList: [String] = ["10,000", "20,000", "40,000", "50,000", "100,000", "200,000"]
    var currentAmountList: [String] = []

    var defaultSelectedIndex: IndexPath = IndexPath(row: 0, section: 0) // Default item index

    var language:String?
    var walletId:String=""
    var walletName:String = ""
    var wallet: String = ""
    var balance: String = ""
    var currency: String = ""
    
    var topUpAmount:String?
    
    let numberFormatter: NumberFormatter = {
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.groupingSeparator = "," // Optional: Change this if you need a different separator
            formatter.groupingSize = 3 // Optional: This is the default, which groups digits in sets of 3
            return formatter
        }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        keyboardHidden()
        
        view.backgroundColor = DefaultAppearance.shared.primaryColor
        // Set the current amount list based on currency
        updateAmountListForCurrency()

        getSharePref()
        B24PaymentSdkHelper.getCurrentLanguage(language: language)
        
        applyToolBar()
        
        inputAmount.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
        setUpTopUI()
        setUpBottomUI()
        setUpColelctionView()
        
        
        //register keyboard
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWilldisplay), name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name:UIResponder.keyboardWillHideNotification, object: nil)
        

    }
    
    
    @objc func keyboardWillHide(){
        UIView.animate(withDuration: 0.3) {
            self.buttonSpaceBottom.constant = 52
        }
       
    }
    
    @objc func keyboardWilldisplay(notification:Notification){
        if let keyboardframe:NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue{
            let keyboardrectangle = keyboardframe.cgRectValue
            let keyboardHeight = keyboardrectangle.height
            
            UIView.animate(withDuration: 0.3) {
                self.buttonSpaceBottom.constant = keyboardHeight + 10
            }
           
            
        }
    }
    
    func keyboardHidden(){
        let tap = UITapGestureRecognizer(target: self, action: #selector(keyboardRemove))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func keyboardRemove(){
        view.endEditing(true)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
            // Remove non-numeric characters except for the decimal separator
            let currentText = textField.text?.replacingOccurrences(of: "[^0-9]", with: "", options: .regularExpression) ?? ""
            
            // Convert the text to a number
            if let number = Double(currentText) {
                // Format the number with thousands separator
                textField.text = numberFormatter.string(from: NSNumber(value: number))
            } else {
                // If the user clears the input, set it to "0"
                textField.text = "0"
            }
        }
    
    
    func getSharePref(){
        if let languageCode = SharedPreferenceManager.getString(forKey: SharePrefKey.lanuageCode.rawValue){
            language = languageCode
        }else{
            language = "km"
        }
        if let pmId = SharedPreferenceManager.getString(forKey: SharePrefKey.paymentMethodId.rawValue){
            walletId = pmId
        }else{
            walletId = ""
        }
        if let walletN = SharedPreferenceManager.getString(forKey: SharePrefKey.walletNo.rawValue){
            wallet = walletN
        }else{
            wallet = ""
        }
        if let amount = SharedPreferenceManager.getString(forKey: SharePrefKey.balance.rawValue){
            balance = amount
        }else{
            balance = ""
        }
        if let currncyCode = SharedPreferenceManager.getString(forKey: SharePrefKey.currency.rawValue){
            currency = currncyCode
        }else{
            currency = ""
        }
        
    }
    
    
    private func applyToolBar(){
            
            let customButton = UIButton(type: .system)
            // Image
            let imageView = UIImageView(image: UIImage(systemName: "chevron.backward"))
            imageView.tintColor = DefaultAppearance.shared.onPrimaryColor
            imageView.contentMode = .scaleAspectFit
            imageView.translatesAutoresizingMaskIntoConstraints = false
            customButton.addSubview(imageView)
            
            let titleLabel = UILabel()
            
            
            titleLabel.text = B24PaymentSdkHelper.localized(TopupLocalizedKeys.topup.rawValue)
            
            titleLabel.textColor = DefaultAppearance.shared.onPrimaryColor
            titleLabel.font = FontManager.shared.mediumFont(forLanguage: language ?? "km", size: FixFontSize.toolbarTitle)
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            customButton.addSubview(titleLabel)

            // Add constraints to position the image and title properly
            NSLayoutConstraint.activate([
                imageView.leadingAnchor.constraint(equalTo: customButton.leadingAnchor,constant: -10),
                imageView.centerYAnchor.constraint(equalTo: customButton.centerYAnchor),
                imageView.widthAnchor.constraint(equalToConstant: 24), // Set desired width
                imageView.heightAnchor.constraint(equalToConstant: 24),
                
                titleLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8),
                titleLabel.centerYAnchor.constraint(equalTo: customButton.centerYAnchor),
                titleLabel.trailingAnchor.constraint(equalTo: customButton.trailingAnchor)
            ])

            // Add action to the button
            customButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

            // Create a UIBarButtonItem with the custom button
            let backButton = UIBarButtonItem(customView: customButton)
            navigationItem.leftBarButtonItem = backButton
        }
        
        // Back button action
        @objc func backButtonTapped() {
            navigationController?.popViewController(animated: true)
        }
    
    

    func updateAmountListForCurrency() {
        switch currency.uppercased() {
        case "USD":
            currentAmountList = usdAmountList
        case "KHR":
            currentAmountList = khrAmountList
        default:
            currentAmountList = usdAmountList // Default to USD if unknown currency
        }
    }

    
//    func setUpColelctionView(){
//        
//        // Register the custom cell
//        let nibName = UINib(nibName: "AmountViewCell", bundle: B24PaymentSdkHelper.frameworkBundle())
//        self.amountCollectionView.register(nibName, forCellWithReuseIdentifier: "AmountViewCell")
//                
//        self.amountCollectionView.delegate = self
//        self.amountCollectionView.dataSource = self
//                
//        self.amountCollectionView.reloadData()
//        // Select the default item
//        amountCollectionView.selectItem(at: defaultSelectedIndex, animated: false, scrollPosition: .centeredVertically)
//        // Set the default item's value to the inputAmount text field
//        topUpAmount = amountList[defaultSelectedIndex.row]
//        inputAmount.text = topUpAmount
//        
//    }

    // Update setUpCollectionView to use currentAmountList
    func setUpColelctionView() {
        let nibName = UINib(nibName: "AmountViewCell", bundle: B24PaymentSdkHelper.frameworkBundle())
        self.amountCollectionView.register(nibName, forCellWithReuseIdentifier: "AmountViewCell")

        self.amountCollectionView.delegate = self
        self.amountCollectionView.dataSource = self

        self.amountCollectionView.reloadData()

        amountCollectionView.selectItem(at: defaultSelectedIndex, animated: false, scrollPosition: .centeredVertically)
        topUpAmount = currentAmountList[defaultSelectedIndex.row]
        inputAmount.text = topUpAmount
    }

    
    func setUpTopUI(){
        
        inputAmount.keyboardType = .decimalPad
        
        contenContainer.backgroundColor = DefaultAppearance.shared.cardColor
        contenContainer.addCardShadow(cornerRadius: 8)
        contenContainer.roundCorners(cornerRadius: 8)
        line.backgroundColor = DefaultAppearance.shared.primaryLabelColor.withAlphaComponent(0.1)
        
        TitleLabel.text = walletName
        TitleLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        TitleLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
        walletNo.text = wallet
        walletNo.textColor = DefaultAppearance.shared.primaryLabelColor
        walletNo.font = FontManager.shared.mediumFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
        balanceLabel.text = B24PaymentSdkHelper.localized(AddWalletLocalizedKeys.balance.rawValue)
        balanceLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        balanceLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
        amountLabel.text = balance
        amountLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        amountLabel.font = FontManager.shared.mediumFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
        currencyLabel.text = currency
        currencyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        currencyLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        
        inputAmount.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.buttonText)
        
    }
    
    func setUpBottomUI() {
        bottomView.backgroundColor = DefaultAppearance.shared.screenBgColor
        chooseAmountLabel.text = B24PaymentSdkHelper.localized(AddWalletLocalizedKeys.choose_amount.rawValue)
        chooseAmountLabel.font = FontManager.shared.regularFont(forLanguage: language ?? "km", size: FixFontSize.contentText)
        chooseAmountLabel.textColor = DefaultAppearance.shared.primaryLabelColor

        lineChooseAmount.backgroundColor = DefaultAppearance.shared.primaryLabelColor.withAlphaComponent(0.1)

        // Configure input amount text field
        inputAmount.backgroundColor = .white
        inputAmount.layer.cornerRadius = 4
        inputAmount.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.buttonText)
        inputAmount.textColor = DefaultAppearance.shared.primaryLabelColor
        self.addPadding(to: inputAmount)

        amountCollectionView.backgroundColor = DefaultAppearance.shared.screenBgColor

        buttonOk.titleLabel?.font = FontManager.shared.mediumFont(forLanguage: language ?? "km", size: FixFontSize.buttonText)
        buttonOk.setTitle(B24PaymentSdkHelper.localized(TopupLocalizedKeys.continueKey.rawValue), for: .normal)
        buttonOk.tintColor = DefaultAppearance.shared.primaryColor
        buttonOk.setTitleColor(DefaultAppearance.shared.onPrimaryColor, for: .normal)
    }

    // Add a helper method to get currency symbol
    private func getCurrencySymbol(for currency: String) -> String {
        switch currency.uppercased() {
        case "USD":
            return "$"
        case "KHR":
            return "៛"
        default:
            return currency // Return the currency code if no symbol is found
        }
    }

    // Update the addPadding method to handle different currencies
    func addPadding(to textField: UITextField) {
        let currencySymbol = getCurrencySymbol(for: currency)
        let currencyLabel = UILabel()
        currencyLabel.text = currencySymbol
        currencyLabel.font = textField.font
        currencyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        currencyLabel.sizeToFit()

        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: currencyLabel.frame.width + 15, height: textField.frame.height))
        currencyLabel.frame = CGRect(x: 10, y: (textField.frame.height - currencyLabel.frame.height) / 2, width: currencyLabel.frame.width, height: currencyLabel.frame.height)
        paddingView.addSubview(currencyLabel)

        textField.leftView = paddingView
        textField.leftViewMode = .always
    }

    // Update collection view methods to use currentAmountList
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return currentAmountList.count
    }

//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = amountCollectionView.dequeueReusableCell(withReuseIdentifier: "AmountViewCell", for:indexPath) as! AmountViewCell
//
//        let amount = amountList[indexPath.row]
//        
//        configAmountCell(cell, with: amount)
//        
//        // Highlight the default selected cell
//        if indexPath == defaultSelectedIndex {
//            cell.container.backgroundColor = DefaultAppearance.shared.primaryColor
//            cell.amountLabel.textColor = DefaultAppearance.shared.onPrimaryColor
//        } else {
//            cell.container.backgroundColor = DefaultAppearance.shared.cardColor
//        }
//        
//        return cell
//        
//    }


    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = amountCollectionView.dequeueReusableCell(withReuseIdentifier: "AmountViewCell", for: indexPath) as! AmountViewCell

        let amount = currentAmountList[indexPath.row]
        configAmountCell(cell, with: amount)

        if indexPath == defaultSelectedIndex {
            cell.container.backgroundColor = DefaultAppearance.shared.primaryColor
            cell.amountLabel.textColor = DefaultAppearance.shared.onPrimaryColor
        } else {
            cell.container.backgroundColor = DefaultAppearance.shared.cardColor
        }

        return cell
    }

//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        if let cell = collectionView.cellForItem(at: indexPath) as? AmountViewCell {
//            cell.container.backgroundColor = DefaultAppearance.shared.primaryColor
//            cell.amountLabel.textColor = DefaultAppearance.shared.onPrimaryColor
//        }
//
//        topUpAmount = amountList[indexPath.row]
//        inputAmount.text = topUpAmount
//
//        // Reapply padding to ensure currency symbol is correctly displayed
//        self.addPadding(to: inputAmount)
//    }


    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? AmountViewCell {
            cell.container.backgroundColor = DefaultAppearance.shared.primaryColor
            cell.amountLabel.textColor = DefaultAppearance.shared.onPrimaryColor
        }

        topUpAmount = currentAmountList[indexPath.row]
        inputAmount.text = topUpAmount

        self.addPadding(to: inputAmount)
    }

    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        // Get the deselected cell
        if let cell = collectionView.cellForItem(at: indexPath) as? AmountViewCell {
            // Revert the background color to the default
            cell.container.backgroundColor = DefaultAppearance.shared.cardColor
            cell.amountLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        }
    }
    
    
    func configAmountCell(_ cell:AmountViewCell, with amount:String){
        cell.container.backgroundColor = DefaultAppearance.shared.cardColor
        cell.container.layer.cornerRadius = 6
        cell.amountLabel.text = amount
        cell.amountLabel.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.buttonText)
        cell.amountLabel.textColor = DefaultAppearance.shared.primaryLabelColor
    }
    
    
    @IBAction func okButtonAction(_ sender: Any) {
        
       topupWallet()
        
//        let storyboard = UIStoryboard(name: "InstantPaymentMethodView", bundle: B24PaymentSdkHelper.frameworkBundle())
//        let vc = storyboard.instantiateViewController(withIdentifier: "SuccessScreenViewController") as! SuccessScreenViewController
//       // vc.transactionSuccess = transaction
//        if let navigationController = self.navigationController {
//            navigationController.pushViewController(vc, animated: true)
//        } else {
//            // If no navigation controller, you can either show an error or fallback to presenting modally
//            print("Navigation Controller not found.")
//        }
        
    }
    
    func topupWallet(){
        
       // print("====TOPUP AMOUNT \(String(describing: topUpAmount))")
        
        let amountWithoutComma = topUpAmount?.replacingOccurrences(of: ",", with: "")
        
        let amount = Decimal(string: amountWithoutComma ?? "0")
        
      //  print("amount is : \(String(describing: amount))")
        
        let payload = TopUp(id: walletId, amount: amount ?? 0.0)
        
        do {
            let jsonData = try JSONEncoder().encode(payload)
            guard let jsonString = String(data: jsonData, encoding: .utf8) else {
                showError(message: "Failed to create payload")
                return
            }

            let encryptedText = try EncryptionHelper.encryptHMACAES(
                plainText: jsonString,
                secretKey: SDKVariableSetting.walletSecretKey
            )
           
            sendRequestTopup(encrypt: encryptedText)

        } catch {
            showError(message: "Encryption failed: \(error.localizedDescription)")
        }
        
    }
    
    //MARK: request Topup
    func sendRequestTopup(encrypt:String){
        let progressDiglog = LoadingView.show(in: self)
        
        AF.request(WalletRouter.topUpWallet(encrypted: encrypt))
            .validate().responseData{
               response in
                switch response.result{
                    case .success(let data):
                    progressDiglog.dismiss()
                        do{
                            let decodedData = try JSONDecoder().decode(ApiResponse<WalletResponseData>.self, from: data)
                            
                            let decryptText = try EncryptionHelper.decryptHMACAES(encryptedBase64: decodedData.data.encrypted!, secretKey:  SDKVariableSetting.walletSecretKey)
                            
                            let decryptedData = decryptText.data(using: .utf8)!
                            
                            // Decode the data into ApiResponse model
                            let checkout = try JSONDecoder().decode(TopUpResponseModel.self, from: decryptedData)
                            
                            //set to check on payment sdk success
                            SharedPreferenceManager.set(value: "TOPUPKEY", forKey: SharePrefKey.topup.rawValue)
                            
                            B24PaymentSdk().initSdk(controller: self,
                                                  transactionId: checkout.tranId,
                                                  refererKey: SDKVariableSetting.xRefererKey,
                                                  language: self.language,
                                                  darkMode:false,
                                                  isProduction: false,
                                                  testingEnv:"STAG"
                                                  
                            )
                            
//                              print("Transaction ID: \(checkout.tranId)")
//                              print("Identity Code: \(checkout.identityCode)")
//                              print("Payment Link: \(checkout.paymentLink)")
//                              print("KHQR String: \(checkout.khqrString)")

//                            print("===========>\(decodedData)")
//                            print("===========>\(decryptText)")
                        }catch {
                            print("Decode Error: \(error)")
                        }
                    
                    case.failure(let error):
                        progressDiglog.dismiss()
                        print("ERROR \(error)")
                }
            }
    }
    
    private func showError(message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(
                title: "Error",
                message: message,
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
    
}

extension TopUpView: UICollectionViewDelegateFlowLayout {
    // Set cell size
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//            let itemsPerRow: CGFloat = 3 // Number of items in a row
//            let padding: CGFloat = 20 // Total padding between items
//            let availableWidth = collectionView.frame.width - (padding * (itemsPerRow + 1))
//            let itemWidth = availableWidth / itemsPerRow
//            return CGSize(width: itemWidth, height: itemWidth * 0.6)
            
            let size = (amountCollectionView.frame.size.width)/4
            return CGSize(width: size,height: 60)
            
        }

//        // Set section insets
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            return UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20) // Padding for the whole section
        }
//
//        // Set spacing between rows
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 20
        }

        // Set spacing between items in the same row
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 20
        }
}
