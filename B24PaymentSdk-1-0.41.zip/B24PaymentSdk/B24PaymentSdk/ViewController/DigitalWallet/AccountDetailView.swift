//
//  AccountDetailView.swift
//  B24PaymentSdk
//
//  Created by visal ny on 22/12/24.
//

import UIKit
import Alamofire

class AccountDetailView: UIViewController{
    
    
    @IBOutlet weak var transactionCollectionView: UICollectionView!
    @IBOutlet weak var containerHeader: UIView!
    @IBOutlet weak var bgLogo: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var iconEdit: UIImageView!
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var contentContainer: UIView!
    @IBOutlet weak var accountNoText: UILabel!
    @IBOutlet weak var accountNameText: UILabel!
    @IBOutlet weak var currencyText: UILabel!
    @IBOutlet weak var accountNoValue: UILabel!
    @IBOutlet weak var accountNameValue: UILabel!
    @IBOutlet weak var currencyValue: UILabel!
    @IBOutlet weak var setDefaultButtonContainer: UIView!
    @IBOutlet weak var setDefaultIcon: UIImageView!
    @IBOutlet weak var setDefaultLabel: UILabel!
    @IBOutlet weak var disableContainer: UIView!
    @IBOutlet weak var disableIcon: UIImageView!
    @IBOutlet weak var disableLabel: UILabel!
    @IBOutlet weak var topupButton: UIButton!
    
    @IBOutlet weak var inactiveLabel: UILabel!
    @IBOutlet weak var bgInactive: UIView!
    @IBOutlet weak var accNoDotView: UILabel!
    
    @IBOutlet weak var accNameDotView: UILabel!
    
    @IBOutlet weak var progressIndicatorMain: UIActivityIndicatorView!
    @IBOutlet weak var progressContainer: UIView!
    @IBOutlet weak var currencyDotView: UILabel!
    
    @IBOutlet weak var emptyLabel: UILabel!

    @IBOutlet weak var toolbarLine: UIView!
    @IBOutlet weak var emptyImage: UIImageView!
    var dataAccountDetail = DataAccountDetail()
    var accountId: String = ""
    var paymentMethodId:String = ""
    var language:String = "km"
    
    var isDefault:Bool = false
    var isInactive:Bool = false
    
    var accountNo:String = "..."
    
    let emptyIconName = "exclamationmark.circle.fill"
    
    var minHeight:Double = 0.0
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = DefaultAppearance.shared.screenBgColor
        toolbarLine.backgroundColor = DefaultAppearance.shared.primaryLabelColor
        
        getSharePref()
        
        applyToolBar()
        
        B24PaymentSdkHelper.getCurrentLanguage(language: language)
       
        accountDetail()
        setupModifyName()
       
    }
    
    
    @IBAction func topUpButtonAction(_ sender: Any) {


        if isInactive{
            let dialog = WarningAlertView()
            dialog.showWarningTopupAlert(from: self) {
             self.updateAccountStatus(inactive: false)
            } cancelHandler: {

            }

        }else{
            let storyboard = UIStoryboard(name: "InstantPaymentMethodView", bundle: B24PaymentSdkHelper.frameworkBundle())
            if let topUpVC = storyboard.instantiateViewController(withIdentifier: "TopUpView") as? TopUpView {
                // Pass the currency from the current account detail
                topUpVC.currency = self.dataAccountDetail.currency
                topUpVC.walletId = self.dataAccountDetail.id
                topUpVC.walletName = self.dataAccountDetail.accountName
                topUpVC.wallet = self.dataAccountDetail.accountNo
                topUpVC.balance = self.dataAccountDetail.amountDisplay

                navigationController?.pushViewController(topUpVC, animated: true)
            }
        }
    }
    
    private func applyToolBar(){
        
        let customButton = UIButton(type: .system)
        // Image
        let imageView = UIImageView(image: UIImage(systemName: "chevron.backward"))
        imageView.tintColor = DefaultAppearance.shared.primaryLabelColor
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        customButton.addSubview(imageView)
        
        let titleLabel = UILabel()
        
        let toolbarTitle:String = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.title.rawValue)
        
        titleLabel.text = toolbarTitle + accountNo
        
        titleLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        titleLabel.font = FontManager.shared.mediumFont(forLanguage: language, size: FixFontSize.toolbarTitle)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        customButton.addSubview(titleLabel)

        // Add constraints to position the image and title properly
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: customButton.leadingAnchor,constant: -10),
            imageView.centerYAnchor.constraint(equalTo: customButton.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 24), // Set desired width
            imageView.heightAnchor.constraint(equalToConstant: 24),
            
            titleLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8),
            titleLabel.centerYAnchor.constraint(equalTo: customButton.centerYAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: customButton.trailingAnchor)
        ])

        // Add action to the button
        customButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

        // Create a UIBarButtonItem with the custom button
        let backButton = UIBarButtonItem(customView: customButton)
        navigationItem.leftBarButtonItem = backButton
    }
    
    // Back button action
    @objc func backButtonTapped() {
      //  navigationController?.popViewController(animated: true)
        if let navigationController = self.navigationController, navigationController.viewControllers.count > 1 {
                // There's a navigation controller and more than one view controller in the stack, so we can pop
                navigationController.popViewController(animated: true)
        } else {
                // No navigation controller or no previous view controller in the stack
            print("Cannot pop view controller. Either no navigation controller or at root view.")
        }
    }
    
    
   private func startLoading() {
       DispatchQueue.main.async {
           self.progressContainer.isHidden = false
           self.progressContainer.backgroundColor = DefaultAppearance.shared.cardColor
           self.progressIndicatorMain.hidesWhenStopped = true
           self.progressIndicatorMain.color = DefaultAppearance.shared.primaryColor
           self.progressContainer.backgroundColor = DefaultAppearance.shared.screenBgColor
           self.progressIndicatorMain.startAnimating()
       }
    }
    
    private func stopLoading() {
        DispatchQueue.main.async {
            self.progressIndicatorMain.stopAnimating()
            self.progressContainer.isHidden = true
            self.progressIndicatorMain.isHidden = true
        }
    }
    
    
    private func getSharePref(){
        if let languageCode = SharedPreferenceManager.getString(forKey: SharePrefKey.lanuageCode.rawValue){
            language = languageCode
        }else{
            language = "km"
        }
        
        if let id = SharedPreferenceManager.getString(forKey: SharePrefKey.paymentMethodId.rawValue){
            paymentMethodId = id
        }else{
            paymentMethodId = ""
        }
    }
    
    private func headerAppearance(data:DataAccountDetail){
        containerHeader.backgroundColor = DefaultAppearance.shared.screenBgColor
        bgLogo.backgroundColor = DefaultAppearance.shared.primaryColor
        bgLogo.layer.cornerRadius = 6
        logo.tintColor = DefaultAppearance.shared.onPrimaryColor
        
        lblTitle.text = data.accountName
        lblTitle.textColor = DefaultAppearance.shared.primaryLabelColor
        lblTitle.font = B24PaymentSdkHelper.setFont(named: "Roboto-Medium", ofSize: FixFontSize.toolbarTitle
        )
        
        iconEdit.tintColor = DefaultAppearance.shared.primaryLabelColor
        
        if isInactive{
            bgInactive.isHidden = false
            bgInactive.backgroundColor = DefaultAppearance.shared.dangerColor
            bgInactive.layer.cornerRadius = 6
            inactiveLabel.textColor = DefaultAppearance.shared.onPrimaryColor
            inactiveLabel.font = FontManager.shared.regularFont(forLanguage: language , size: 12)
            inactiveLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.inActive.rawValue)
            
        }else{
            if isDefault{
                bgInactive.isHidden = false
                bgInactive.backgroundColor = DefaultAppearance.shared.primaryColor
                bgInactive.layer.cornerRadius = 6
                inactiveLabel.textColor = DefaultAppearance.shared.onPrimaryColor
                inactiveLabel.font = FontManager.shared.regularFont(forLanguage: language , size: 12)
                inactiveLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.DefaultACC.rawValue)
            }else{
                bgInactive.isHidden = true
            }
        }
        
    }
    
    private func contentAppearance(data:DataAccountDetail){
        contentContainer.backgroundColor = DefaultAppearance.shared.cardColor
        contentContainer.addCardShadow(cornerRadius: 8)
        contentContainer.roundCorners(cornerRadius: 8)
        
        accNoDotView.textColor = DefaultAppearance.shared.primaryLabelColor
        accNameDotView.textColor = DefaultAppearance.shared.primaryLabelColor
        currencyDotView.textColor = DefaultAppearance.shared.primaryLabelColor
    
        
        // apply color
        accountNoText.textColor = DefaultAppearance.shared.primaryLabelColor
        accountNameText.textColor = DefaultAppearance.shared.primaryLabelColor
        currencyText.textColor = DefaultAppearance.shared.primaryLabelColor
        
        accountNoValue.textColor = DefaultAppearance.shared.primaryLabelColor
        accountNameValue.textColor = DefaultAppearance.shared.primaryLabelColor
        currencyValue.textColor = DefaultAppearance.shared.primaryLabelColor
        
        // apply text
        if data.type == AvailablePMType.wallet.rawValue{
            accountNoText.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.walletId.rawValue)
            accountNameText.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_wallet_ballance.rawValue)
            accountNameValue.text = data.amountDisplay
        }else{
            accountNoText.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.accNo.rawValue)
            accountNameText.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_account_name.rawValue)
            accountNameValue.text = data.accountName
        }
        
        currencyText.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_currency.rawValue)
        accountNoValue.text = data.accountNo
        currencyValue.text = data.currency
       
        //apply font
        accountNoText.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
        accountNoValue.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
        accountNameText.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
        accountNameValue.font = FontManager.shared.mediumFont(forLanguage: language , size: FixFontSize.contentText)
        currencyText.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
        currencyValue.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
        
    }
    
    func buttonAppearance(data:DataAccountDetail){
        
        setDefaultButtonContainer.backgroundColor = DefaultAppearance.shared.cardColor
        setDefaultButtonContainer.layer.cornerRadius = 8
        
        disableContainer.backgroundColor = DefaultAppearance.shared.cardColor
        disableContainer.layer.cornerRadius = 8
        
        //size
        setDefaultLabel.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_set_default.rawValue)
        disableLabel.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.buttonText)

        if isDefault{
            setDefaultIcon.tintColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
            setDefaultLabel.textColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
            disableIcon.tintColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
            disableLabel.textColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
//            disableIcon.image = UIImage(systemName: "circle.slash.fill")
            disableLabel.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_disable.rawValue)
            
            setupSetDefualtButtonEvent(clickable: false)
            setupDisableAccountEvent(clickable: false)
            
        }else{
           
            if(isInactive){
                
                //default icon
                setDefaultIcon.tintColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
                setDefaultLabel.textColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
                disableIcon.tintColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
                disableLabel.textColor = DefaultAppearance.shared.secondaryLabelColor.withAlphaComponent(0.3)
//                disableIcon.image = UIImage(systemName: "circle.slash.fill")
                disableLabel.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_disable.rawValue)
                
                
                disableIcon.tintColor = DefaultAppearance.shared.primaryColor
                disableIcon.image = UIImage(systemName: "checkmark.circle.fill")
                disableLabel.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_enable.rawValue)
                disableLabel.textColor = DefaultAppearance.shared.primaryColor
                //action to enable
                setupEnableAccountEvent()
                
                
                // action on set default
                setupSetDefualtButtonEvent(clickable: false)
                
                
            }else{
                
                setDefaultLabel.textColor = DefaultAppearance.shared.primaryColor
                setDefaultIcon.tintColor = DefaultAppearance.shared.primaryColor
                
                // action on set default
                setupSetDefualtButtonEvent(clickable: true)
                
                
                disableIcon.tintColor = DefaultAppearance.shared.dangerColor
//                disableIcon.image = UIImage(systemName: "circle.slash.fill")
                disableLabel.text = B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_disable.rawValue)
                disableLabel.textColor = DefaultAppearance.shared.dangerColor
                //action to inactive
                setupDisableAccountEvent(clickable: true)
                
            }
        }
    }
    
    func topUpButtonAppearance(){
        topupButton.tintColor = DefaultAppearance.shared.primaryColor
        topupButton.setTitleColor(DefaultAppearance.shared.onPrimaryColor, for: .normal)
        topupButton.setTitle(B24PaymentSdkHelper.localized(AccountDetailLocalizedKeys.detail_top_up.rawValue), for: .normal)
        topupButton.titleLabel?.font = FontManager.shared.boldFont(forLanguage: language , size: FixFontSize.buttonText)
    }
    
    
    
//    func showBottomSheet() {
//        // Instantiate your BottomSheetViewController
//        let storyboard = UIStoryboard(name: "InstantPaymentMethodView", bundle: B24PaymentSdkHelper.frameworkBundle())
//            guard let bottomSheetVC = storyboard.instantiateViewController(withIdentifier: "TransactionsView") as? TransactionsView else { return }
//        presentLegacyBottomSheet(bottomSheetVC)
//
//    }
    
    var transactionBottomSheet:TransactionsView?

    func showBottomSheet() {
        
        dismissBottomSheet()
        
            let storyboard = UIStoryboard(name: "InstantPaymentMethodView", bundle: B24PaymentSdkHelper.frameworkBundle())
            guard let bottomSheetVC = storyboard.instantiateViewController(withIdentifier: "TransactionsView") as? TransactionsView else { return }
        
            transactionBottomSheet = bottomSheetVC
    
            // Pass the account ID
            transactionBottomSheet?.accountId = self.paymentMethodId
        
            presentLegacyBottomSheet(transactionBottomSheet!)
            
    }
    
    func dismissBottomSheet(){
        // If there's a bottom sheet and it's currently presented, dismiss it
            if let bottomSheet = transactionBottomSheet, bottomSheet.isViewLoaded && bottomSheet.view.superview != nil {
                // Start dismissal animation before presenting the new one
                UIView.animate(withDuration: 0.3, animations: {
                    bottomSheet.view.frame.origin.y = self.view.bounds.height
                }, completion: { _ in
                    bottomSheet.view.removeFromSuperview()
                    bottomSheet.removeFromParent()

                    // Optionally reset any state after dismissal
                    print("Bottom sheet dismissed.")
                })
            }
    }
    
   
    
    
    func presentLegacyBottomSheet(_ bottomSheetVC: TransactionsView) {
        // Add as a child view controller
        addChild(bottomSheetVC)

        // Configure the bottom sheet view
        let screenHeight = view.bounds.height
       // let mediumHeight = screenHeight * 0.4 // Medium detent (40% of screen height)
        let mediumHeight = screenHeight * minHeight
        let largeHeight = screenHeight * 0.9  // Large detent (80% of screen height)
        
        bottomSheetVC.view.frame = CGRect(x: 0, y: screenHeight, width: view.bounds.width, height: largeHeight)
        bottomSheetVC.view.layer.cornerRadius = 16
        bottomSheetVC.view.layer.masksToBounds = true
        
        // Add the bottom sheet to the main view
        view.addSubview(bottomSheetVC.view)
        bottomSheetVC.didMove(toParent: self)

        // Add gesture recognizer for dragging
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        bottomSheetVC.view.addGestureRecognizer(panGesture)

        // Animate the bottom sheet sliding up to medium detent
        UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
            bottomSheetVC.view.frame.origin.y = screenHeight - mediumHeight
        }, completion: nil)
    }

    // MARK: - Gesture Handling

    @objc private func handlePanGesture(_ gesture: UIPanGestureRecognizer) {
        guard let bottomSheetView = gesture.view else { return }
        let screenHeight = view.bounds.height
        let mediumHeight = screenHeight * 0.4
        let largeHeight = screenHeight * 0.9

        let translation = gesture.translation(in: view)
        _ = gesture.velocity(in: view)

        switch gesture.state {
        case .changed:
            // Move the bottom sheet as the user drags
            let newY = bottomSheetView.frame.origin.y + translation.y
            if newY >= screenHeight - largeHeight && newY <= screenHeight - mediumHeight {
                bottomSheetView.frame.origin.y = newY
            }
            gesture.setTranslation(.zero, in: view)
        case .ended:
            // Snap to the nearest detent based on velocity or position
            let currentY = bottomSheetView.frame.origin.y
            let nearestDetent = abs(currentY - (screenHeight - mediumHeight)) < abs(currentY - (screenHeight - largeHeight))
                ? mediumHeight : largeHeight

            UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
                bottomSheetView.frame.origin.y = screenHeight - nearestDetent
            }, completion: nil)

        default:
            break
        }
    }
    
    
    // MARK:request detail
    
    private func accountDetail(){
    
        startLoading()
        
        AF.request(WalletRouter.instantPaymentMethodDetail(id: paymentMethodId))
            .validate().responseData{
                [self](response) in
                switch response.result{
                case .success(let data):
                   
                    do{
                        let decodeData = try JSONDecoder().decode(ApiResponse<DataAccountDetail>.self,from: data)
                        if decodeData.code == "SUCCESS"{
                        
                            stopLoading()
                            
                            minHeight = 0.4
                            
                            dataAccountDetail = decodeData.data
                            
                            isDefault = dataAccountDetail.isDefault
                            isInactive = dataAccountDetail.inactive
                            accountNo = dataAccountDetail.accountNo
                            DispatchQueue.main.async {
                                self.applyToolBar()
                                self.showBottomSheet()
                            }
                            headerAppearance(data: dataAccountDetail)
                            contentAppearance(data: dataAccountDetail)
    
                            buttonAppearance(data: dataAccountDetail)
                            
                            topUpButtonAppearance()
                
                            
                            //set share Preference
                            setSharePref(pmId: dataAccountDetail.id, walletName: dataAccountDetail.accountName, walletNo: dataAccountDetail.accountNo, amount: dataAccountDetail.amountDisplay, currency: dataAccountDetail.currency)
                            
                            dismissBottomSheet()
                            
                        }else{
                            
                            progressIndicatorMain.stopAnimating()
                            progressIndicatorMain.isHidden = true
                            
                            emptyImage.image = UIImage(systemName: emptyIconName)
                            emptyImage.tintColor = DefaultAppearance.shared.warningColor
                            emptyLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
                            emptyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
                            emptyLabel.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
                            
                            
                            let message = language == "en" ? decodeData.message : decodeData.messageKh
                            
                            B24PaymentSdkHelper.errorSnackbar(view: view,
                                                              message: message )
                        }
                        
                    }catch{
                        print("Decode Error: \(error)")
                    }
                case .failure(let error):
                   
                    
                    print("==>\(error)")
                    
                    progressIndicatorMain.stopAnimating()
                    progressIndicatorMain.isHidden = true
                    
                    emptyImage.image = UIImage(systemName: emptyIconName)
                    emptyImage.tintColor = DefaultAppearance.shared.warningColor
                    emptyLabel.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
                    emptyLabel.textColor = DefaultAppearance.shared.primaryLabelColor
                    emptyLabel.font = FontManager.shared.regularFont(forLanguage: language , size: FixFontSize.contentText)
                    
                    B24PaymentSdkHelper.errorSnackbar(
                                    view: view,
                                    message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                                                        forBottomSheet: false
                                                )
                    
                }
            }
        
    }
    
    // MARK: Set Account Default
    func setAccountDefult(){
        let payload = SetDefaultPayload(
            id: paymentMethodId)
        
        do {
            let jsonData = try JSONEncoder().encode(payload)
            guard let jsonString = String(data: jsonData, encoding: .utf8) else {
                print( "Failed to create payload")
                return
            }

            let encryptedText = try EncryptionHelper.encryptHMACAES(
                plainText: jsonString,
                secretKey: SDKVariableSetting.walletSecretKey
            )
           
            sendSetDetaultAccount(encrypt: encryptedText)

        } catch {
            print("Encryption failed: \(error.localizedDescription)")
        }
    }
    // MARK: request set detautl account
    func sendSetDetaultAccount(encrypt: String){
     
        let progressDiglog = LoadingView.show(in: self)
        
        AF.request(WalletRouter.setDetault(encrypted: encrypt))
            .validate().responseData{
               response in
                switch response.result{
                    case .success(let data):
                    progressDiglog.dismiss()
                        do{
                            let decodedData = try JSONDecoder().decode(ApiResponse<WalletResponseData>.self, from: data)
                            
                            if decodedData.code == "SUCCESS"{
                                DispatchQueue.main.async {
                                    self.isDefault = !self.isDefault

                                    self.headerAppearance(data: self.dataAccountDetail)
                                    self.buttonAppearance(data: self.dataAccountDetail)
                                }
                            
                            }else{
                                let message = self.language == "en" ? decodedData.message : decodedData.messageKh
                                
                                B24PaymentSdkHelper.errorSnackbar(view: self.view,
                                                                  message: message )
                            }
                            
                            print("===========>\(decodedData)")
                        }catch{
                            print("Decode Error: \(error)")
                       
                        }
                    
                    case.failure(let error):
                        progressDiglog.dismiss()
                    B24PaymentSdkHelper.errorSnackbar(
                        view:self.view,
                                    message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                                                        forBottomSheet: false
                                                )
                        print("ERROR \(error)")
                }
            }
    }
    
    
    func setupSetDefualtButtonEvent(clickable:Bool){
        setDefaultButtonContainer.isUserInteractionEnabled = clickable
        let tabAction = UITapGestureRecognizer(target: self, action: #selector(setDefaultTap))
        setDefaultButtonContainer.addGestureRecognizer(tabAction)
    }
    
    @objc func setDefaultTap(){
        
        let dialog = CustomAlertView()
        
        dialog.showCustomAlert(from: self, isDefaultIcon: true, message: B24PaymentSdkHelper.localized(DialogLocalizedKeys.set_default.rawValue)) {
            self.setAccountDefult()
        } cancelHandler: {
            
        }

    }
    
    func setupDisableAccountEvent(clickable:Bool){
        
        disableContainer.isUserInteractionEnabled = clickable
        let tabAction = UITapGestureRecognizer(target: self, action: #selector(disableAccount))
        disableContainer.addGestureRecognizer(tabAction)
    }
    
    
    @objc func disableAccount(){
        
        let dialog = WarningAlertView()
        dialog.showWarningAlert(from: self) {
            self.updateAccountStatus(inactive: true)
        } cancelHandler: {
            
        }

        
    }
    
    func setupEnableAccountEvent(){
        
        disableContainer.isUserInteractionEnabled = true
        let tabAction = UITapGestureRecognizer(target: self, action: #selector(enableAccount))
        disableContainer.addGestureRecognizer(tabAction)
    }
    
    
    @objc func enableAccount(){
       let dialog = CustomAlertView()
        dialog.showCustomAlert(from: self, isDefaultIcon: false, message: B24PaymentSdkHelper.localized(DialogLocalizedKeys.enable.rawValue)) {
            self.updateAccountStatus(inactive: false)
        } cancelHandler: {
            
        }

        
    }
    
    func updateAccountStatus(inactive:Bool){
        let payload = UpdateStatus(
            id: paymentMethodId,
            inactive: inactive)
        
        do {
            let jsonData = try JSONEncoder().encode(payload)
            guard let jsonString = String(data: jsonData, encoding: .utf8) else {
                print("Failed to create payload")
                return
            }

            let encryptedText = try EncryptionHelper.encryptHMACAES(
                plainText: jsonString,
                secretKey: SDKVariableSetting.walletSecretKey
            )
           
            sendUpdateStatus(encrypt: encryptedText,inactive: inactive)

        } catch {
            print("Encryption failed: \(error.localizedDescription)")
        }
        
        
    }
    
    //MARK: request update status
    func sendUpdateStatus(encrypt:String,inactive:Bool){
        let progressDiglog = LoadingView.show(in: self)
        
        AF.request(WalletRouter.updateStatus(encrypted: encrypt))
            .validate().responseData{
               response in
                switch response.result{
                    case .success(let data):
                    progressDiglog.dismiss()
                        do{
                            let decodedData = try JSONDecoder().decode(ApiResponse<WalletResponseData>.self, from: data)
                            
                            if decodedData.code == "SUCCESS"{
                                DispatchQueue.main.async {
                                    //self.isDefault = false
                                    self.isInactive = inactive
                                    
                                    self.headerAppearance(data: self.dataAccountDetail)
                                    self.buttonAppearance(data: self.dataAccountDetail)
                                }
                            }else{
                                let message = self.language == "en" ? decodedData.message : decodedData.messageKh
                                
                                B24PaymentSdkHelper.errorSnackbar(view: self.view,
                                                                  message: message )
                            }
                            
                
                        }catch{
                            print("Decode Error: \(error)")
                       
                        }
                    
                    case.failure(let error):
                        progressDiglog.dismiss()
                    B24PaymentSdkHelper.errorSnackbar(
                        view:self.view,
                                    message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                                                        forBottomSheet: false
                                                )
                        print("ERROR \(error)")
                }
            }
    }
    
    
    
    func setupModifyName(){
        iconEdit.isUserInteractionEnabled = true
        let tabAction = UITapGestureRecognizer(target: self, action: #selector(modifyNameTapped))
        iconEdit.addGestureRecognizer(tabAction)
    }
    
    @objc func modifyNameTapped(){
        
        if isInactive{
            let dialog = WarningAlertView()
            dialog.showWarningTopupAlert(from: self) {
                self.updateAccountStatus(inactive: false)
            } cancelHandler: {
                
            }

        }else{
//            let dialog = EditDialog()
//            dialog.showEditDialog(from: self) { inputText in
//                self.modifyName(name: inputText)
//            } cancelHandler: {
//                
//            }

            let dialog = EditDialog()
              dialog.showEditDialog(
                  from: self,
                  defaultText: self.dataAccountDetail.accountName  // Pass the current name
              ) { inputText in
                  self.modifyName(name: inputText)
              } cancelHandler: {

              }
        }
    }
    
    func modifyName(name:String){
        
        
        let payload = ModifyNamePayload(id: paymentMethodId, name: name)
        
        do {
            let jsonData = try JSONEncoder().encode(payload)
            guard let jsonString = String(data: jsonData, encoding: .utf8) else {
               print("Failed to create payload")
                return
            }

            let encryptedText = try EncryptionHelper.encryptHMACAES(
                plainText: jsonString,
                secretKey: SDKVariableSetting.walletSecretKey
            )
           
            sendModifyRequest(encrypt: encryptedText,name: name)

        } catch {
            print( "Encryption failed: \(error.localizedDescription)")
        }
    }
    
    //MARK: requst modify name
    func sendModifyRequest(encrypt:String,name:String){
        let progressDiglog = LoadingView.show(in: self)
        
        AF.request(WalletRouter.modifyWalletName(encrypted: encrypt))
            .validate().responseData{
               response in
                switch response.result{
                    case .success(let data):
                    progressDiglog.dismiss()
                        do{
                            let decodedData = try JSONDecoder().decode(ApiResponse<WalletResponseData>.self, from: data)
                            
                            if decodedData.code == "SUCCESS"{
                                self.lblTitle.text = name
                            }else{
                                let message = self.language == "en" ? decodedData.message : decodedData.messageKh
                                
                                B24PaymentSdkHelper.errorSnackbar(view: self.view,
                                                                  message: message )
                            }
                            
                            print("===========>\(decodedData)")
                        }catch{
                            print("Decode Error: \(error)")
                       
                        }
                    
                    case.failure(let error):
                        progressDiglog.dismiss()
                    B24PaymentSdkHelper.errorSnackbar(
                        view: self.view,
                                    message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                                                        forBottomSheet: false
                                                )
                        print("ERROR \(error)")
                }
            }
    }
   
    
    private func setSharePref(pmId:String,walletName:String,walletNo:String,amount:String,currency:String){
        SharedPreferenceManager.set(value: pmId, forKey: SharePrefKey.paymentMethodId.rawValue)
        SharedPreferenceManager.set(value: walletName, forKey: SharePrefKey.walletName.rawValue)
        SharedPreferenceManager.set(value: walletNo, forKey: SharePrefKey.walletNo.rawValue)
        SharedPreferenceManager.set(value: amount, forKey: SharePrefKey.balance.rawValue)
        SharedPreferenceManager.set(value: currency, forKey: SharePrefKey.currency.rawValue)

    }
    
}


// MARK: - Account Detail View Extension
//extension AccountDetailView {
//
//    // MARK: - Setup Methods
//    private func setupLoadingIndicator() {
//        view.addSubview(loadingIndicator)
//        NSLayoutConstraint.activate([
//            loadingIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            loadingIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
//        ])
//    }
//
//    private func updateLoadingState() {
//        DispatchQueue.main.async {
//            if self.isLoading {
//                self.loadingIndicator.startAnimating()
//                self.contentContainer.isHidden = true
//            } else {
//                self.loadingIndicator.stopAnimating()
//                self.contentContainer.isHidden = false
//            }
//        }
//    }
    

    // MARK: - API Methods
//    func fetchAccountDetail(accountId: String) {
//        isLoading = true
//
//        let url = APIManager.merchantApiUrl().appendingPathComponent("instantpaymentsdk/payment_method/detail")
//        let parameters: [String: Any] = ["id": accountId]
//
//        AF.request(
//            url,
//            method: .post,
//            parameters: parameters,
//            encoding: JSONEncoding.default,
//            headers: APIManager.initHeader()
//        )
//        .validate()
//        .responseDecodable(of: ApiResponse<DataAccountDetail>.self) { [weak self] response in
//            guard let self = self else { return }
//            self.isLoading = false
//
//            switch response.result {
//            case .success(let apiResponse):
//                self.handleSuccessResponse(apiResponse)
//            case .failure(let error):
//                self.handleError(error)
//            }
//        }
//    }

    // MARK: - Response Handlers
//    private func handleSuccessResponse(_ apiResponse: ApiResponse<DataAccountDetail>) {
//        if apiResponse.code == "SUCCESS" {
//            DispatchQueue.main.async {
//                self.updateUI(with: apiResponse.data)
//            }
//        } else {
//            showError(message: apiResponse.message)
//        }
//    }

//    private func handleError(_ error: AFError) {
//        let errorMessage: String
//        switch error {
//        case .responseValidationFailed(let reason):
//            errorMessage = "Validation failed: \(reason)"
//        case .responseSerializationFailed(let reason):
//            errorMessage = "Failed to process response: \(reason)"
//        case .sessionTaskFailed(let error):
//            errorMessage = "Network error: \(error.localizedDescription)"
//        default:
//            errorMessage = "An unexpected error occurred"
//        }
//        showError(message: errorMessage)
//    }

    // MARK: - UI Updates
//    private func updateUI(with data: DataAccountDetail) {
//        self.dataAccountDetail = data
//
//        headerAppearance(data: data)
//        contentAppearance(data: data)
//        buttonAppearance(data: data)
//
//        // Update logo if available
//        if !data.logo.isEmpty {
//            loadLogo(from: data.logo)
//        }
//    }

//    private func loadLogo(from urlString: String) {
//        guard let url = URL(string: urlString) else { return }
//
//        DispatchQueue.global().async {
//            if let data = try? Data(contentsOf: url),
//               let image = UIImage(data: data) {
//                DispatchQueue.main.async {
//                    self.logo.image = image
//                }
//            }
//        }
//    }

    // MARK: - Error Handling
//    private func showError(message: String) {
//        DispatchQueue.main.async {
//            let alert = UIAlertController(
//                title: "Error",
//                message: message,
//                preferredStyle: .alert
//            )
//            alert.addAction(UIAlertAction(title: "OK", style: .default))
//            self.present(alert, animated: true)
//        }
//    }
//}

// MARK: - View Controller Lifecycle
//extension AccountDetailView {
//    private func setupInitialUI() {
//        view.backgroundColor = DefaultAppearance.shared.screenBgColor
//        getSharePref()
//        B24PaymentSdkHelper.getCurrentLanguage(language: language)
//        showBottomSheet()
//
//        // Setup initial state with default data
//        headerAppearance(data: dataAccountDetail)
//        contentAppearance(data: dataAccountDetail)
//        buttonAppearance(data: dataAccountDetail)
//        topUpButtonAppearance()
//    }
//}
