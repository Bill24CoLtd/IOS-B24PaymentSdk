import UIKit
import Alamofire

class AddWalletView: UIViewController {
    // MARK: - Properties
    private var loadingView: LoadingView?
    private let customerSyncCode = "C001"
    private let options = ["USD", "KHR"]
    var language:String = "km"

    // MARK: - UI Components
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = DefaultAppearance.shared.screenBgColor
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    

    private let walletNameField: UITextField = {
        let field = UITextField()
        field.translatesAutoresizingMaskIntoConstraints = false
        field.placeholder = "Wallet Name"
        field.backgroundColor = DefaultAppearance.shared.onPrimaryColor
        field.layer.cornerRadius = 8
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.systemGray5.cgColor
        // Set placeholder text color
        let placeholderText = "Wallet Name"
        let placeholderColor = DefaultAppearance.shared.primaryLabelColor
        field.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [.foregroundColor: placeholderColor]
        )
        return field
       
    }()

    private let currencyField: UITextField = {
        let field = UITextField()
        field.translatesAutoresizingMaskIntoConstraints = false
        field.placeholder = "Currency"
        field.backgroundColor = DefaultAppearance.shared.onPrimaryColor
        field.layer.cornerRadius = 8
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.systemGray5.cgColor
        field.tintColor = .clear
        field.textColor = DefaultAppearance.shared.primaryLabelColor
        return field
    }()

    private lazy var saveButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle(AddWalletLocalizedKeys.save.rawValue, for: .normal)
        button.titleLabel?.font = FontManager.shared.mediumFont(forLanguage: language, size: FixFontSize.buttonText)
        button.backgroundColor = DefaultAppearance.shared.primaryColor
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        return button
    }()

    private let dropdownImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(systemName: "chevron.down"))
        imageView.tintColor = DefaultAppearance.shared.primaryLabelColor
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    private let pickerView = UIPickerView()

    private lazy var customDoneView: UIView = {
        let view = UIView()
        view.backgroundColor = DefaultAppearance.shared.screenBgColor
        view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 60)

        let doneButton = UIButton(type: .system)
        doneButton.frame = CGRect(x: 0, y: 0, width: 120, height: 40)
        doneButton.center = CGPoint(x: view.bounds.width / 2, y: view.bounds.height / 2)
        doneButton.backgroundColor = DefaultAppearance.shared.primaryColor
        doneButton.setTitle("Done", for: .normal)
        doneButton.setTitleColor(.white, for: .normal)
        doneButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        doneButton.layer.cornerRadius = 20
        doneButton.layer.shadowColor = UIColor.black.cgColor
        doneButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        doneButton.layer.shadowRadius = 4
        doneButton.layer.shadowOpacity = 0.1
        doneButton.addTarget(self, action: #selector(doneTapped), for: .touchUpInside)

        view.addSubview(doneButton)

        let separatorLine = UIView()
        separatorLine.backgroundColor = .systemGray5
        separatorLine.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 0.5)
        view.addSubview(separatorLine)

        return view
    }()
    
    

    @IBOutlet weak var toolbarLine: UIView!
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        toolbarLine.backgroundColor = DefaultAppearance.shared.primaryLabelColor
        
        getSharePef()
        B24PaymentSdkHelper.getCurrentLanguage(language: language)

        applyToolBar()

        setupView()
        setupConstraints()
        setupPickerView()
        setupTextFields()
        //applySeparateLine()

    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//
//        // Animate the appearance of the separator line
//        UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
//            self.applySeparateLine()
//        }, completion: nil)
//    }

    private func getSharePef(){
        if let languageCode = SharedPreferenceManager.getString(forKey: SharePrefKey.lanuageCode.rawValue){
            language = languageCode
        }else{
            language = "km"
        }
    }

    private func applySeparateLine() {
        guard let navigationBar = self.navigationController?.navigationBar else { return }

        let separatorLine = UIView()
        separatorLine.backgroundColor = DefaultAppearance.shared.primaryLabelColor
            .withAlphaComponent(0.5)
        separatorLine.tag = 100
        separatorLine.translatesAutoresizingMaskIntoConstraints = false
        separatorLine.alpha = 0.5// Set opacity to 50%

        // Add the separator line without animation
        navigationBar.addSubview(separatorLine)
        NSLayoutConstraint.activate([
            separatorLine.leadingAnchor.constraint(equalTo: navigationBar.leadingAnchor),
            separatorLine.trailingAnchor.constraint(equalTo: navigationBar.trailingAnchor),
            separatorLine.bottomAnchor.constraint(equalTo: navigationBar.bottomAnchor, constant: 10.5),
            separatorLine.heightAnchor.constraint(equalToConstant: 1)
        ])

    }



    // Add this method to remove the line when leaving the screen
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        // Remove the separator line
        navigationController?.navigationBar.subviews.forEach { view in
            if view.tag == 100 {
                view.removeFromSuperview()
            }
        }
    }

    private func applyToolBar(){
        
        let customButton = UIButton(type: .system)
        // Image
        let imageView = UIImageView(image: UIImage(systemName: "chevron.backward"))
        imageView.tintColor = DefaultAppearance.shared.primaryLabelColor
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        customButton.addSubview(imageView)
        
        let titleLabel = UILabel()
        
        titleLabel.text = B24PaymentSdkHelper.localized(AddWalletLocalizedKeys.title.rawValue)
        
        titleLabel.textColor = DefaultAppearance.shared.primaryLabelColor
        titleLabel.font = FontManager.shared.mediumFont(forLanguage: language, size: FixFontSize.toolbarTitle)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        customButton.addSubview(titleLabel)

        // Add constraints to position the image and title properly
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: customButton.leadingAnchor,constant: -10),
            imageView.centerYAnchor.constraint(equalTo: customButton.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 24), // Set desired width
            imageView.heightAnchor.constraint(equalToConstant: 24),
            
            titleLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8),
            titleLabel.centerYAnchor.constraint(equalTo: customButton.centerYAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: customButton.trailingAnchor)
        ])

        // Add action to the button
        customButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

        // Create a UIBarButtonItem with the custom button
        let backButton = UIBarButtonItem(customView: customButton)
        navigationItem.leftBarButtonItem = backButton
    }
    
    // Back button action
    @objc func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }

    // MARK: - Setup Methods
    private func setupView() {
        view.backgroundColor = DefaultAppearance.shared.screenBgColor

        view.addSubview(containerView)
        containerView.addSubview(walletNameField)
        containerView.addSubview(currencyField)
        containerView.addSubview(saveButton)

        saveButton.addTarget(self, action: #selector(buttonSave), for: .touchUpInside)
    }

    private func setupConstraints() {
        NSLayoutConstraint.activate([
            // Container View
            containerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 25), // Increased top padding
            containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            // Wallet Name Field
            walletNameField.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
            walletNameField.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            walletNameField.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            walletNameField.heightAnchor.constraint(equalToConstant: 50),

            // Currency Field
            currencyField.topAnchor.constraint(equalTo: walletNameField.bottomAnchor, constant: 16),
            currencyField.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            currencyField.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            currencyField.heightAnchor.constraint(equalToConstant: 50),

            // Save Button
            saveButton.topAnchor.constraint(equalTo: currencyField.bottomAnchor, constant: 24),
            saveButton.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            saveButton.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            saveButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func setupTextFields() {
        addPadding(to: walletNameField)
        setupCurrencyField()
    }

    private func setupCurrencyField() {
        addPadding(to: currencyField)

        dropdownImageView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 20))
        containerView.addSubview(dropdownImageView)
        dropdownImageView.center = containerView.center

        currencyField.rightView = containerView
        currencyField.rightViewMode = .always

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(currencyFieldTapped))
        currencyField.addGestureRecognizer(tapGesture)
        currencyField.isUserInteractionEnabled = true
    }

    private func setupPickerView() {
        pickerView.delegate = self
        pickerView.dataSource = self
        currencyField.inputView = pickerView
        currencyField.inputAccessoryView = customDoneView
        currencyField.text = options[0]
    }

    // MARK: - Helper Methods
    private func addPadding(to textField: UITextField) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftView = paddingView
        textField.leftViewMode = .always
    }

    // MARK: - Actions
    @objc private func currencyFieldTapped() {
        currencyField.becomeFirstResponder()
        rotateDropdownArrow(up: true)

        UIView.animate(withDuration: 0.3) {
            self.pickerView.alpha = 1.0
        }
    }

    @objc private func doneTapped() {
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.impactOccurred()

        UIView.animate(withDuration: 0.1, animations: {
            self.customDoneView.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }) { _ in
            UIView.animate(withDuration: 0.1) {
                self.customDoneView.transform = .identity
            }
        }

        UIView.animate(withDuration: 0.3, animations: {
            self.pickerView.alpha = 0.0
        }) { _ in
            self.currencyField.resignFirstResponder()
            self.rotateDropdownArrow(up: false)
        }
    }

    private func rotateDropdownArrow(up: Bool) {
        UIView.animate(withDuration: 0.3) {
            self.dropdownImageView.transform = up ? CGAffineTransform(rotationAngle: .pi) : .identity
        }
    }

    @objc private func buttonSave(_ sender: Any) {
        guard let accountName = walletNameField.text, !accountName.isEmpty,
              let currency = currencyField.text, !currency.isEmpty else {
            showError(message: "Please fill in all fields")
            return
        }

        let payload = WalletPayload(
            account_name: accountName,
            customer_sync_code: customerSyncCode,
            currency: currency
        )

        do {
            let jsonData = try JSONEncoder().encode(payload)
            guard let jsonString = String(data: jsonData, encoding: .utf8) else {
                showError(message: "Failed to create payload")
                return
            }

            let encryptedText = try EncryptionHelper.encryptHMACAES(
                plainText: jsonString,
                secretKey: SDKVariableSetting.walletSecretKey
            )

            sendEncryptedWalletData(encryptedText)

        } catch {
            showError(message: "Encryption failed: \(error.localizedDescription)")
        }
    }

    // MARK: - Networking
    private func sendEncryptedWalletData(_ encryptedData: String) {
        let url = APIManager.merchantApiUrl().appendingPathComponent("instantpaymentsdk/create/wallet")
        let parameters: [String: Any] = ["encrypted": encryptedData]

        loadingView = LoadingView.show(in: self)

        AF.request(
            url,
            method: .post,
            parameters: parameters,
            encoding: JSONEncoding.default,
            headers: APIManager.initWalletHeader()
        ).responseData { [weak self] response in
            guard let self = self else { return }

            self.loadingView?.dismiss {
                switch response.result {
                case .success(let data):
                    do {
                        let decoder = JSONDecoder()
                        let apiResponse = try decoder.decode(ApiResponse<WalletResponseData>.self, from: data)

                        if apiResponse.code == "SUCCESS" {
                            DispatchQueue.main.async {
                                self.handleSuccessfulWalletCreation()
                            }
                        } else {
                            DispatchQueue.main.async {
                                self.showError(message: apiResponse.message)
                            }
                        }
                    } catch {
                        print("Decoding error:", error)
                        DispatchQueue.main.async {
                            self.showError(message: "Failed to process server response.")
                        }
                    }
                case .failure(let error):
                    print("Network error:", error)
                    DispatchQueue.main.async {
                        self.showError(message: "Network error: \(error.localizedDescription)")
                    }
                }
            }
        }
    }

    private func handleSuccessfulWalletCreation() {
//        if let availablePaymentMethodVC = navigationController?.viewControllers.first(
//            where: { $0 is InstantPaymentMethodViewController }
//        ) {
//            navigationController?.popToViewController(availablePaymentMethodVC, animated: true)
//        } else {
//            print("Could not find the target view controller.")
//        }
        navigationController?.popToRootViewController(animated: true)

    }

    private func showError(message: String) {
        let alert = UIAlertController(
            title: "Error",
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - UIPickerView Delegate and Data Source
extension AddWalletView: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return options.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return options[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        currencyField.text = options[row]
    }
}
