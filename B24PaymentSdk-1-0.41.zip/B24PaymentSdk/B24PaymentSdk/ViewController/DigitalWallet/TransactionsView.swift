import UIKit
import Alamofire

class TransactionsView: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var transactionCollectionView: UICollectionView!
    @IBOutlet weak var indicator: UIView!
    @IBOutlet weak var progressIndicator: UIActivityIndicatorView!
    
    private var transactions: [DWalletTransaction] = []
    var accountId: String = ""

    private var currentPage = 1
    private let pageSize = 10
    private var isLastPage = false
    var language:String = ""

    private var isLoading: Bool = false {
        didSet {
            updateLoadingState()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = DefaultAppearance.shared.cardColor
        
        getSharePref()
        
        setUpCollectionViewCell()
        indicatorAppearance()

        // Add footer loading view
        view.addSubview(footerLoadingView)
        NSLayoutConstraint.activate([
            footerLoadingView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            footerLoadingView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20)
        ])

        // Add empty data label with top alignment
        view.addSubview(emptyDataLabel)
        emptyDataLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            emptyDataLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyDataLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40), // Add padding from top
            emptyDataLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            emptyDataLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        fetchTransactions() // Fetch transactions when the view loads
    }
    
    
    private func startLoading(){
        progressIndicator.color = DefaultAppearance.shared.primaryColor
        progressIndicator.tintColor = DefaultAppearance.shared.primaryColor
        progressIndicator.startAnimating()
    }
    
    private func stopLoading(){
        progressIndicator.startAnimating()
        progressIndicator.isHidden = true
    }
    
    
    private func getSharePref(){
        if let languageCode = SharedPreferenceManager.getString(forKey: SharePrefKey.lanuageCode.rawValue){
            language = languageCode
        }else{
            language = "km"
        }
    }

    private func setUpCollectionViewCell() {
        let nibName = UINib(nibName: "TransactionViewCell", bundle: B24PaymentSdkHelper.frameworkBundle())
        self.transactionCollectionView.backgroundColor = DefaultAppearance.shared.cardColor
        self.transactionCollectionView.register(nibName, forCellWithReuseIdentifier: "TransactionViewCell")
        self.transactionCollectionView.delegate = self
        self.transactionCollectionView.dataSource = self
    }

    private func indicatorAppearance() {
        indicator.backgroundColor = DefaultAppearance.shared.screenBgColor
        indicator.layer.cornerRadius = 4
    }


    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let frameHeight = scrollView.frame.size.height

        if offsetY > contentHeight - frameHeight * 1.5 {
            fetchTransactions()
        }
    }

    private let footerLoadingView: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.hidesWhenStopped = true
        indicator.color = DefaultAppearance.shared.primaryColor
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()

    private lazy var emptyDataLabel: UIView = {
            let containerView = UIView()
            containerView.isHidden = true
            containerView.translatesAutoresizingMaskIntoConstraints = false

            // Create exclamation icon image view
            let iconImageView = UIImageView()
            iconImageView.translatesAutoresizingMaskIntoConstraints = false
            iconImageView.image = UIImage(systemName: "exclamationmark.circle.fill")
            iconImageView.tintColor = DefaultAppearance.shared.warningColor
            iconImageView.contentMode = .scaleAspectFit

            // Create label
            let label = UILabel()
            label.translatesAutoresizingMaskIntoConstraints = false
            label.text = B24PaymentSdkHelper.localized(PaymentMethodWalletLocalizedKeys.emptyText.rawValue)
            label.textColor = DefaultAppearance.shared.secondaryLabelColor
        label.font = FontManager.shared.regularFont(forLanguage: self.language , size: FixFontSize.contentText)
            label.textAlignment = .center
            label.numberOfLines = 0
       

            // Add subviews
            containerView.addSubview(iconImageView)
            containerView.addSubview(label)

            // Setup constraints
            NSLayoutConstraint.activate([
                iconImageView.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
                iconImageView.topAnchor.constraint(equalTo: containerView.topAnchor),
                iconImageView.widthAnchor.constraint(equalToConstant: 40),
                iconImageView.heightAnchor.constraint(equalToConstant: 40),

                label.topAnchor.constraint(equalTo: iconImageView.bottomAnchor, constant: 16),
                label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 20),
                label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -20),
                label.bottomAnchor.constraint(equalTo: containerView.bottomAnchor)
            ])

            return containerView
        }()

    // MARK: - Fetch Transactions
    private func fetchTransactions() {
        guard !isLoading, !isLastPage else { return }
        isLoading = true
        footerLoadingView.startAnimating()
        
        
        startLoading()

        let url = APIManager.merchantApiUrl().appendingPathComponent("instantpaymentsdk/payment_method/transactions")
        let parameters: [String: Any] = [
            "id": accountId,
            "pagination": [
                "current_page": currentPage,
                "page_size": pageSize
            ]
        ]

        AF.request(
            url,
            method: .post,
            parameters: parameters,
            encoding: JSONEncoding.default,
            headers: APIManager.initHeader()
        )
        .validate()
        .responseDecodable(of: DWalletTransactionResponseModel.self) { [weak self] response in
            guard let self = self else { return }
            self.isLoading = false
            self.footerLoadingView.stopAnimating()

            switch response.result {
            case .success(let responseModel):
                if responseModel.code == "SUCCESS" {
                    stopLoading()
                    self.transactions.append(contentsOf: responseModel.data.transactions)
                    self.isLastPage = responseModel.data.pagination.hasNextPage == false
                    self.transactionCollectionView.reloadData()
                    self.emptyDataLabel.isHidden = !self.transactions.isEmpty
                    self.currentPage += 1
                } else {
                    self.showError(message: responseModel.message)
                }
            case .failure(let error):
                print("=====>\(error)")
                stopLoading()
                //self.showError(message: "Network error: \(error.localizedDescription)")
                B24PaymentSdkHelper.errorSnackbar(
                    view:self.view,
                                message: B24PaymentSdkHelper.localized(SnackBarLocalizedKeys.error.rawValue),
                                                    forBottomSheet: false)
            }
        }
    }

    // MARK: - Loading State
    private func updateLoadingState() {
        DispatchQueue.main.async {
            self.footerLoadingView.isHidden = !self.isLoading
            if ( !self.isLoading){
                self.emptyDataLabel.isHidden = !self.transactions.isEmpty
                // Keep the collection view visible at all times
            }
        }
    }

    // MARK: - Error Handling
    private func showError(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    // MARK: - Collection View Data Source
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return transactions.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = transactionCollectionView.dequeueReusableCell(withReuseIdentifier: "TransactionViewCell", for: indexPath) as! TransactionViewCell
        let transaction = transactions[indexPath.item]
        configureTransactionCell(cell, with: transaction)
        return cell
    }

    private func configureTransactionCell(_ cell: TransactionViewCell, with transaction: DWalletTransaction) {
        cell.container.backgroundColor = DefaultAppearance.shared.cardColor
    
        cell.bgLogo.layer.cornerRadius = cell.bgLogo.frame.size.width/2
        cell.bgLogo.clipsToBounds = true
        
        cell.line.backgroundColor = DefaultAppearance.shared.screenBgColor.withAlphaComponent(0.5)

        if transaction.tranType == TransactionType.walletTopup.rawValue {
            cell.logo.image = UIImage(systemName: "arrow.down.left")
            cell.bgLogo.backgroundColor = DefaultAppearance.shared.primaryColor.withAlphaComponent(0.4)
            cell.amountLabel.textColor = DefaultAppearance.shared.primaryColor
        } else {
            cell.logo.image = UIImage(systemName: "arrow.up.left")
            cell.bgLogo.backgroundColor = DefaultAppearance.shared.dangerColor.withAlphaComponent(0.4)
            cell.amountLabel.textColor = DefaultAppearance.shared.dangerColor
        }

        cell.tranDateLabel.text = transaction.tranDate
        cell.tranDateLabel.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.tranText)
        cell.tranDateLabel.textColor = DefaultAppearance.shared.secondaryLabelColor

        cell.detailLabel.text = transaction.description
        cell.detailLabel.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishRegular, ofSize: FixFontSize.tranTypeText)
        cell.detailLabel.textColor = DefaultAppearance.shared.secondaryLabelColor

        cell.amountLabel.text = transaction.amountDisplay
        cell.amountLabel.font = B24PaymentSdkHelper.setFont(named: FixFontFamily.fontEnglishMedium, ofSize: FixFontSize.buttonText)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedTransaction = transactions[indexPath.item]
        let storyboard = UIStoryboard(name: "InstantPaymentMethodView", bundle: B24PaymentSdkHelper.frameworkBundle())
        guard let transactionDetailVC = storyboard.instantiateViewController(withIdentifier: "TransactionDetailView") as? TransactionDetailView else { return }

        // Pass the transaction ID to the detail view
        transactionDetailVC.tranID = selectedTransaction.tranID

        transactionDetailVC.modalPresentationStyle = .pageSheet
        self.present(transactionDetailVC, animated: true)
    }

}
