//
//  InstantPmViewCellControllerCollectionViewCell.swift
//  B24PaymentSdk
//
//  Created by visal ny on 18/12/24.
//

import UIKit

class InstantPmViewCelll: UICollectionViewCell {
    
    @IBOutlet weak var imgLogo: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var subTitle: UILabel!
    @IBOutlet weak var imgDefault: UIImageView!
    

    
}
