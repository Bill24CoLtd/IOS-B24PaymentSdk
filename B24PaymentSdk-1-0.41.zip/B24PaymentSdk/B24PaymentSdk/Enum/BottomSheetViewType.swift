//
//  BottomSheetViewType.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 23/10/23.
//
import Foundation

public enum BottomSheetViewType {
    case full
    case sixtyPercent
    case thirtyPercent
}
