//
//  TransactionType.swift
//  B24PaymentSdk
//
//  Created by visal ny on 26/12/24.
//

import Foundation

public enum TransactionType:String{
    case walletTopup = "wallet_topup"
}
