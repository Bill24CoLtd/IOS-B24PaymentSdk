//
//  FixFontFamily.swift
//  B24PaymentSdk
//
//  Created by visal ny on 20/12/24.
//

import Foundation

public class FixFontFamily{
    static let fontKhmerRegular = "Battambang-Regular"
    static let fontKhmerMedium = "battambang-bold"
    static let fontKhmerBold = "battambang-bold"
    
    static let fontEnglishRegular = "Roboto-Regular"
    static let fontEnglishMedium = "Roboto-Medium"
    static let fontEnglishBold = "Roboto-Bold"
    
}
