//
//  TransactionType.swift
//  B24PaymentSdk
//
//  Created by visal ny on 20/12/24.
//

import Foundation

enum AvailablePMType: String {
    case wallet = "wallet"
    case cardOfFile = "card_on_file"
}
