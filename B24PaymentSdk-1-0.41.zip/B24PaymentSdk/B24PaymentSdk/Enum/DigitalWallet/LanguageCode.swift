//
//  LanguageCode.swift
//  B24PaymentSdk
//
//  Created by visal ny on 20/12/24.
//

import Foundation

public class LanguageCode{
    static let khmerCode = "km"
    static let englishCode = "en"
}
