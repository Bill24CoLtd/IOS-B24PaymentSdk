//
//  SharePrefKey.swift
//  B24PaymentSdk
//
//  Created by visal ny on 26/12/24.
//

import Foundation

enum SharePrefKey:String{
    case lanuageCode
    case customerSyncode
    case paymentMethodId
    case walletName
    case walletNo
    case balance
    case currency
    case topup
}
