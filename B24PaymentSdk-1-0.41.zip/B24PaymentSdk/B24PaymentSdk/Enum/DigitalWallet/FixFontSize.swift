//
//  FixFontSize.swift
//  B24PaymentSdk
//
//  Created by visal ny on 20/12/24.
//

import Foundation

class FixFontSize {
    static let toolbarTitle: CGFloat = 17.0
    static let cardTitle: CGFloat = 16.0
    static let cardSubTitle: CGFloat = 14.0
    static let buttonText: CGFloat = 15.0
    static let tranText: CGFloat = 13.0
    static let tranTypeText: CGFloat = 12.0
    static let contentText: CGFloat = 14.0
}
