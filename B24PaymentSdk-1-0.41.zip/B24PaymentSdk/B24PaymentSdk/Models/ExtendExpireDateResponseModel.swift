//
//  ExtendExpireDateResponseModel.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 25/10/23.
//

import Foundation

struct ExtendExpireDateResponse: Codable {
    let code, message, messageKh: String?
    let data: DataExpireDate?

    enum CodingKeys: String, CodingKey {
        case code, message
        case messageKh = "message_kh"
        case data
    }
}

struct DataExpireDate: Codable {
    let expiredDate: String

    enum CodingKeys: String, CodingKey {
        case expiredDate = "expired_date"
    }
}

