//
//  FavoriteBankResponseModel.swift
//  Bill24OnlinePaymentSdk
//
//  Created by MacbookPro on 1/11/23.
//

import Foundation

// MARK: - FavoriteBankResponse
struct FavoriteBankResponse: Codable {
    let code, message, messageKh: String?
    let data: FavoriteBankData?

    enum CodingKeys: String, CodingKey {
        case code, message
        case messageKh = "message_kh"
        case data
    }
}

// MARK: - DataClass
struct FavoriteBankData: Codable {
}

