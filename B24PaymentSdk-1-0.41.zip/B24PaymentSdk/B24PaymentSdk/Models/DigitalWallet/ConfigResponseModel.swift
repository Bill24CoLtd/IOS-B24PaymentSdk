//
//  ConfigResponseModel.swift
//  B24PaymentSdk
//
//  Created by visal ny on 19/12/24.
//

import Foundation

struct ConfigResponseModel:Codable{
    
    let code, message, messageKh: String
    let data:DataAppearance
    
    enum CodingKeys: String, CodingKey {
            case code, message
            case messageKh = "message_kh"
            case data
        }
    
}

struct DataAppearance:Codable{
    let appearance: DWalletAppearance
}
