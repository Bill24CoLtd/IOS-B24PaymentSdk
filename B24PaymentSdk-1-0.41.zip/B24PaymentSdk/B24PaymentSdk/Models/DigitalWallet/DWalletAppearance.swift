//
//  DWalletAppearance.swift
//  B24PaymentSdk
//
//  Created by visal ny on 19/12/24.
//

import Foundation

struct DWalletAppearance: Codable{
    var lightMode: DWalletMode?
    var darkMode: DWalletMode?
    
    enum CodingKeys: String, CodingKey {
            case lightMode = "light_mode"
            case darkMode = "dark_mode"
        }
}
